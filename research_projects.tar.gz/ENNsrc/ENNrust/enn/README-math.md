# ENN Mathematical Contract

## Core Symbols
- K: Number of latent states per neuron
- ψₜ ∈ ℝᴷ: Entangled state vector
- E ∈ ℝᴷˣᴷ: Entanglement matrix (PSD: E = L·Lᵀ)
- λ ≥ 0: Decoherence parameter
- Wₓ, Wₕ, Wₘ, b: Weight matrices and bias
- φ: Elementwise nonlinearity (tanh/ELU)

## Cell Update (Deterministic)
```
ψₜ₊₁ = φ(Wₓxₜ + Wₕhₜ + Eψₜ - λψₜ + b)
```

## Collapse Mechanism
```
αₜ = softmax(Wₘψₜ)
zₜ = αₜᵀψₜ
```

## Regularizers
1. **PSD/Symmetry on E**: Parametrize as E = L·Lᵀ or penalize ‖E - Eᵀ‖²_F
2. **Collapse Control**: KL(α ‖ one-hot) with schedule (start small, increase)
3. **Norm Control**: η‖ψ‖²

## Optional Stochastic Extensions
- **Itô**: dψₜ = f(ψₜ,xₜ,hₜ)dt + G(ψₜ,xₜ,hₜ)dWₜ
- **Stratonovich**: Uses midpoint rule, preserves chain rule
- **Drift Correction**: μ° = μ - ½(∂G/∂ψ)·G

## Training Objectives
```
L = L_task(z,y) + β·reg_E + γ·KL(α‖one-hot) + η·‖ψ‖²
```

## Correctness Criteria
- PSD property: all eigenvalues of E ≥ 0
- Softmax normalization: Σᵢ αᵢ = 1
- Collapse entropy: H(α) decreases with training
- For committor: z ∈ [0,1], isocommittor at z ≈ 0.5