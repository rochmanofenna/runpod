use enn_core::types::F;
use nalgebra::DVector;
use serde::{Serialize, Deserialize};

/// Committor label: q(φ) = P(hit B before A | start at φ)
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CommittorLabel {
    pub phi: DVector<F>,        // State features
    pub q: F,                   // Committor value [0,1]
    pub path_id: u64,           // Source path identifier
    pub time_index: usize,      // Time step along path
}

/// Builder for committor labels from transition path ensembles
pub struct CommittorBuilder {
    pub a_region: Box<dyn Fn(&DVector<F>) -> bool + Send + Sync>,  // Region A predicate
    pub b_region: Box<dyn Fn(&DVector<F>) -> bool + Send + Sync>,  // Region B predicate
}

impl CommittorBuilder {
    pub fn new(
        a_predicate: Box<dyn Fn(&DVector<F>) -> bool + Send + Sync>,
        b_predicate: Box<dyn Fn(&DVector<F>) -> bool + Send + Sync>,
    ) -> Self {
        Self {
            a_region: a_predicate,
            b_region: b_predicate,
        }
    }
    
    /// Create simple geometric regions for testing
    pub fn geometric_regions(
        a_center: DVector<F>, 
        a_radius: F,
        b_center: DVector<F>, 
        b_radius: F
    ) -> Self {
        let a_pred = Box::new(move |phi: &DVector<F>| {
            (phi - &a_center).norm() <= a_radius
        });
        
        let b_pred = Box::new(move |phi: &DVector<F>| {
            (phi - &b_center).norm() <= b_radius
        });
        
        Self::new(a_pred, b_pred)
    }
    
    /// Compute committor from a single path
    /// Returns committor labels for each point along the path
    pub fn compute_path_committor(
        &self, 
        path_states: &[DVector<F>],
        path_id: u64
    ) -> Vec<CommittorLabel> {
        let mut labels = Vec::new();
        let n_steps = path_states.len();
        
        for (t_idx, phi) in path_states.iter().enumerate() {
            // Look forward from this point to see if we hit B before A
            let mut hit_b = false;
            let mut hit_a = false;
            
            for future_state in &path_states[t_idx..] {
                if (self.b_region)(future_state) {
                    hit_b = true;
                    break;
                }
                if (self.a_region)(future_state) {
                    hit_a = true;
                    break;
                }
            }
            
            // Committor q = 1 if hit B first, 0 if hit A first, NaN if neither
            let q = if hit_b && !hit_a {
                1.0
            } else if hit_a && !hit_b {
                0.0
            } else {
                continue; // Skip ambiguous points
            };
            
            labels.push(CommittorLabel {
                phi: phi.clone(),
                q,
                path_id,
                time_index: t_idx,
            });
        }
        
        labels
    }
    
    /// Process multiple paths to build committor dataset
    pub fn build_dataset(
        &self,
        paths: &[Vec<DVector<F>>]  // Vector of paths, each path is Vec<state>
    ) -> Vec<CommittorLabel> {
        let mut all_labels = Vec::new();
        
        for (path_id, path) in paths.iter().enumerate() {
            let path_labels = self.compute_path_committor(path, path_id as u64);
            all_labels.extend(path_labels);
        }
        
        all_labels
    }
}

/// Simple 2D double-well committor for testing
pub fn double_well_committor_exact(x: F, y: F) -> F {
    // Analytical approximation for double-well potential V(x,y) = (x²-1)² + y²
    // A region: x < -0.5, B region: x > 0.5
    if x < -0.5 {
        0.0  // In A
    } else if x > 0.5 {
        1.0  // In B  
    } else {
        // Approximate committor in transition region
        0.5 + 0.5 * (2.0 * x).tanh()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_geometric_regions() {
        let a_center = DVector::from_vec(vec![-1.0, 0.0]);
        let b_center = DVector::from_vec(vec![1.0, 0.0]);
        let builder = CommittorBuilder::geometric_regions(a_center, 0.3, b_center, 0.3);
        
        // Test point in A
        let point_a = DVector::from_vec(vec![-1.1, 0.0]);
        assert!((builder.a_region)(&point_a), "Point should be in region A");
        assert!(!(builder.b_region)(&point_a), "Point should not be in region B");
        
        // Test point in B  
        let point_b = DVector::from_vec(vec![1.1, 0.0]);
        assert!(!(builder.a_region)(&point_b), "Point should not be in region A");
        assert!((builder.b_region)(&point_b), "Point should be in region B");
    }
    
    #[test]
    fn test_simple_path_committor() {
        let a_center = DVector::from_vec(vec![-1.0]);
        let b_center = DVector::from_vec(vec![1.0]);
        let builder = CommittorBuilder::geometric_regions(a_center, 0.2, b_center, 0.2);
        
        // Simple path: A → transition → B
        let path = vec![
            DVector::from_vec(vec![-1.0]),  // Start in A
            DVector::from_vec(vec![-0.5]),  // Transition
            DVector::from_vec(vec![0.0]),   // Middle
            DVector::from_vec(vec![0.5]),   // Transition  
            DVector::from_vec(vec![1.0]),   // End in B
        ];
        
        let labels = builder.compute_path_committor(&path, 0);
        
        // Should get labels for transition states pointing toward eventual B hit
        assert!(!labels.is_empty(), "Should generate some committor labels");
        
        // Last few states should have q=1 (will hit B)
        if let Some(last_label) = labels.iter().find(|l| l.time_index == 3) {
            assert_eq!(last_label.q, 1.0, "State before B should have q=1");
        }
    }
}