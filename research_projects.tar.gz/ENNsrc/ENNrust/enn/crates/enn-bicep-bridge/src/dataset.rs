use enn_core::types::F;
use nalgebra::DVector;
use crate::committor::CommittorLabel;

/// Features extracted from BICEP paths for ENN training
#[derive(Clone, Debug)]
pub struct PathFeatures {
    pub state: DVector<F>,           // Current state φₜ
    pub velocity: Option<DVector<F>>, // dφ/dt (finite difference)
    pub local_variance: Option<F>,    // Local volatility estimate
    pub time: F,                     // Time coordinate
}

impl PathFeatures {
    pub fn from_state(state: DVector<F>, time: F) -> Self {
        Self {
            state,
            velocity: None,
            local_variance: None,
            time,
        }
    }
    
    pub fn with_velocity(mut self, velocity: DVector<F>) -> Self {
        self.velocity = Some(velocity);
        self
    }
    
    pub fn with_variance(mut self, variance: F) -> Self {
        self.local_variance = Some(variance);
        self
    }
    
    /// Convert to input vector for ENN (flattened features)
    pub fn to_input_vector(&self) -> DVector<F> {
        let mut features = self.state.clone();
        
        // Append velocity if available
        if let Some(ref vel) = self.velocity {
            let mut combined = DVector::zeros(features.len() + vel.len());
            combined.rows_mut(0, features.len()).copy_from(&features);
            combined.rows_mut(features.len(), vel.len()).copy_from(vel);
            features = combined;
        }
        
        // Append variance if available
        if let Some(var) = self.local_variance {
            let mut combined = DVector::zeros(features.len() + 1);
            combined.rows_mut(0, features.len()).copy_from(&features);
            combined[features.len()] = var;
            features = combined;
        }
        
        // Append time
        let mut final_features = DVector::zeros(features.len() + 1);
        final_features.rows_mut(0, features.len()).copy_from(&features);
        final_features[features.len()] = self.time;
        
        final_features
    }
}

/// Dataset for training ENN on BICEP-generated committor data
pub struct BicepDataset {
    pub samples: Vec<(PathFeatures, F)>,  // (features, committor_target)
    pub train_split: f64,                 // Fraction for training
}

impl BicepDataset {
    pub fn new(train_split: f64) -> Self {
        Self {
            samples: Vec::new(),
            train_split: train_split.clamp(0.0, 1.0),
        }
    }
    
    /// Add committor labels to dataset
    pub fn add_committor_labels(&mut self, labels: Vec<CommittorLabel>) {
        for label in labels {
            let features = PathFeatures::from_state(label.phi, label.time_index as F);
            self.samples.push((features, label.q));
        }
    }
    
    /// Add synthetic double-well data for testing
    pub fn add_synthetic_double_well(&mut self, n_samples: usize, rng: &mut impl rand::Rng) {
        use rand_distr::{Distribution, Uniform};
        
        let x_dist = Uniform::new(-2.0, 2.0);
        let y_dist = Uniform::new(-1.0, 1.0);
        
        for _ in 0..n_samples {
            let x: F = x_dist.sample(rng);
            let y: F = y_dist.sample(rng);
            let state = DVector::from_vec(vec![x, y]);
            
            // Use analytical double-well committor
            let q = crate::committor::double_well_committor_exact(x, y);
            
            let features = PathFeatures::from_state(state, 0.0);
            self.samples.push((features, q));
        }
    }
    
    /// Split into training and validation sets
    pub fn split(&self) -> (Vec<(PathFeatures, F)>, Vec<(PathFeatures, F)>) {
        let n_train = (self.samples.len() as f64 * self.train_split) as usize;
        
        let train_samples = self.samples[..n_train].to_vec();
        let val_samples = self.samples[n_train..].to_vec();
        
        (train_samples, val_samples)
    }
    
    /// Get batch of samples for training
    pub fn get_batch(&self, batch_size: usize, start_idx: usize) -> Vec<(DVector<F>, F)> {
        let end_idx = (start_idx + batch_size).min(self.samples.len());
        
        self.samples[start_idx..end_idx]
            .iter()
            .map(|(features, target)| (features.to_input_vector(), *target))
            .collect()
    }
    
    /// Dataset statistics
    pub fn stats(&self) -> DatasetStats {
        if self.samples.is_empty() {
            return DatasetStats::default();
        }
        
        let committor_values: Vec<F> = self.samples.iter().map(|(_, q)| *q).collect();
        let mean_q = committor_values.iter().sum::<F>() / committor_values.len() as F;
        let var_q = committor_values.iter()
            .map(|q| (q - mean_q).powi(2))
            .sum::<F>() / committor_values.len() as F;
        
        // Count transition states (q ≈ 0.5)
        let n_transition = committor_values.iter()
            .filter(|&&q| (q - 0.5).abs() < 0.1)
            .count();
        
        DatasetStats {
            n_samples: self.samples.len(),
            mean_committor: mean_q,
            var_committor: var_q,
            n_transition_states: n_transition,
            input_dim: if let Some((features, _)) = self.samples.first() {
                features.to_input_vector().len()
            } else {
                0
            },
        }
    }
}

#[derive(Debug, Default)]
pub struct DatasetStats {
    pub n_samples: usize,
    pub mean_committor: F,
    pub var_committor: F,
    pub n_transition_states: usize,
    pub input_dim: usize,
}

#[cfg(test)]
mod tests {
    use super::*;
    use rand::SeedableRng;
    
    #[test]
    fn test_synthetic_double_well() {
        let mut rng = rand_chacha::ChaCha20Rng::seed_from_u64(42);
        let mut dataset = BicepDataset::new(0.8);
        
        dataset.add_synthetic_double_well(1000, &mut rng);
        
        let stats = dataset.stats();
        assert_eq!(stats.n_samples, 1000);
        assert!(stats.mean_committor > 0.0 && stats.mean_committor < 1.0);
        assert!(stats.n_transition_states > 0, "Should have some transition states");
        
        // Test train/val split
        let (train, val) = dataset.split();
        assert_eq!(train.len(), 800);
        assert_eq!(val.len(), 200);
    }
    
    #[test]
    fn test_batch_generation() {
        let mut rng = rand_chacha::ChaCha20Rng::seed_from_u64(123);
        let mut dataset = BicepDataset::new(1.0);
        dataset.add_synthetic_double_well(100, &mut rng);
        
        let batch = dataset.get_batch(10, 0);
        assert_eq!(batch.len(), 10);
        
        // Check feature vector dimensions are consistent
        let input_dim = batch[0].0.len();
        assert!(input_dim >= 2, "Should include at least x,y coordinates");
        
        for (features, target) in &batch {
            assert_eq!(features.len(), input_dim);
            assert!(*target >= 0.0 && *target <= 1.0, "Committor should be in [0,1]");
        }
    }
}