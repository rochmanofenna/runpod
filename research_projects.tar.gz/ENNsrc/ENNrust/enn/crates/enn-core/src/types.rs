use nalgebra::{DVector, DMatrix};
use serde::{Serialize, Deserialize};

/// Floating point type (can swap to f32 or Complex later)
pub type F = f64;

/// Entangled state vector ψ ∈ ℝᴷ
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Psi(pub DVector<F>);

/// Matrix type alias
pub type Mat = DMatrix<F>;

impl Psi {
    pub fn new(k: usize) -> Self {
        Psi(DVector::zeros(k))
    }
    
    pub fn from_vec(v: Vec<F>) -> Self {
        Psi(DVector::from_vec(v))
    }
    
    pub fn random(k: usize, rng: &mut impl rand::Rng) -> Self {
        use rand_distr::{Distribution, StandardNormal};
        let values: Vec<F> = (0..k)
            .map(|_| { let val: f64 = StandardNormal.sample(rng); val * 0.1 })
            .collect();
        Psi::from_vec(values)
    }
    
    pub fn dim(&self) -> usize {
        self.0.len()
    }
    
    pub fn norm_squared(&self) -> F {
        self.0.norm_squared()
    }
}

/// Cell state containing entangled state and hidden vector
#[derive(Clone, Debug)]
pub struct CellState {
    pub psi: Psi,
    pub h: DVector<F>,
}

impl CellState {
    pub fn new(psi: Psi, h: DVector<F>) -> Self {
        Self { psi, h }
    }
    
    pub fn zeros(k: usize, h_dim: usize) -> Self {
        Self {
            psi: Psi::new(k),
            h: DVector::zeros(h_dim),
        }
    }
}

/// Cell input
#[derive(Clone, Debug)]
pub struct CellInput {
    pub x: DVector<F>,
}

impl CellInput {
    pub fn from_vec(v: Vec<F>) -> Self {
        Self { x: DVector::from_vec(v) }
    }
}

/// Collapse output with attention weights and scalar readout
#[derive(Clone, Debug)]
pub struct CollapseOut {
    pub alpha: DVector<F>,  // Attention weights (softmax output)
    pub z: F,               // Scalar readout: αᵀψ
    pub entropy: F,         // H(α) for monitoring collapse
}

impl CollapseOut {
    pub fn new(alpha: DVector<F>, psi: &Psi) -> Self {
        let z = alpha.dot(&psi.0);
        let entropy = -alpha.iter()
            .filter(|&&a| a > 1e-12)
            .map(|&a| a * a.ln())
            .sum::<F>();
        
        Self { alpha, z, entropy }
    }
}