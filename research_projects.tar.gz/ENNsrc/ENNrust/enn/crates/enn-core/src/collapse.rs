use crate::types::F;
use nalgebra::DVector;

/// Stable softmax implementation
pub fn softmax(logits: &DVector<F>) -> DVector<F> {
    let max_logit = logits.max();
    let exp_shifted = logits.map(|x| (x - max_logit).exp());
    let sum = exp_shifted.sum();
    exp_shifted / sum
}

/// KL divergence KL(p || q)
pub fn kl_divergence(p: &DVector<F>, q: &DVector<F>) -> F {
    assert_eq!(p.len(), q.len());
    
    p.iter().zip(q.iter())
        .filter(|(&pi, &qi)| pi > 1e-12 && qi > 1e-12)
        .map(|(&pi, &qi)| pi * (pi / qi).ln())
        .sum()
}

/// KL divergence from uniform to one-hot (for collapse regularization)
pub fn kl_one_hot(alpha: &DVector<F>) -> F {
    let k = alpha.len() as F;
    let uniform = 1.0 / k;
    
    // KL(α || uniform)
    alpha.iter()
        .filter(|&&a| a > 1e-12)
        .map(|&a| a * (a / uniform).ln())
        .sum()
}

/// Multi-head readout for vector outputs
pub struct MultiHeadCollapse {
    pub n_heads: usize,
    pub k: usize,
}

impl MultiHeadCollapse {
    pub fn new(n_heads: usize, k: usize) -> Self {
        Self { n_heads, k }
    }
    
    pub fn collapse(&self, logits: &nalgebra::DMatrix<F>, psi: &crate::types::Psi) -> Vec<F> {
        // Each row of logits is one head's scores
        let mut outputs = Vec::with_capacity(self.n_heads);
        
        for i in 0..self.n_heads {
            let head_logits = logits.row(i).transpose();
            let alpha = softmax(&head_logits);
            let z = alpha.dot(&psi.0);
            outputs.push(z);
        }
        
        outputs
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_softmax() {
        let logits = DVector::from_vec(vec![1.0, 2.0, 3.0, 4.0]);
        let probs = softmax(&logits);
        
        // Should sum to 1
        assert!((probs.sum() - 1.0).abs() < 1e-10);
        
        // Should be monotonic
        for i in 0..3 {
            assert!(probs[i] < probs[i + 1]);
        }
    }
    
    #[test]
    fn test_kl_divergence() {
        let k = 4;
        let uniform = DVector::repeat(k, 1.0 / k as F);
        
        // KL(uniform || uniform) should be 0
        let kl = kl_divergence(&uniform, &uniform);
        assert!(kl.abs() < 1e-10);
        
        // One-hot distribution
        let mut one_hot = DVector::zeros(k);
        one_hot[0] = 1.0;
        
        // KL(one_hot || uniform) should be ln(k)
        let kl = kl_divergence(&one_hot, &uniform);
        assert!((kl - (k as F).ln()).abs() < 1e-10);
    }
}