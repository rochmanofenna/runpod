use crate::types::{F, Psi, Mat, CellState, CellInput, CollapseOut};
use crate::collapse::softmax;
use crate::regularizers::psd_from_factor;
use nalgebra::{DVector};

/// Entangled neural cell 
/// ψₜ₊₁ = φ(Wₓxₜ + Wₕhₜ + Eψₜ - λψₜ + b)
pub struct EntangledCell {
    pub k: usize,               // Number of latent states
    pub input_dim: usize,       
    pub hidden_dim: usize,
    
    // Weight matrices
    pub wx: Mat,                // K × input_dim
    pub wh: Mat,                // K × hidden_dim
    pub wg: Mat,                // K × K (gating/collapse)
    pub b: DVector<F>,          // K (bias)
    
    // Entanglement (PSD via L·Lᵀ)
    pub l_factor: Mat,          // K × K lower triangular
    
    // Decoherence
    pub lambda: F,
    
    // Nonlinearity
    pub phi: fn(F) -> F,
}

impl EntangledCell {
    pub fn new(
        k: usize,
        input_dim: usize, 
        hidden_dim: usize,
        lambda: F,
        phi: fn(F) -> F,
        rng: &mut impl rand::Rng,
    ) -> Self {
        use rand_distr::{Distribution, StandardNormal};
        
        // Xavier-style initialization
        let wx_scale = (2.0 / (input_dim + k) as F).sqrt();
        let wh_scale = (2.0 / (hidden_dim + k) as F).sqrt();
        let wg_scale = (1.0 / k as F).sqrt();
        
        // Initialize weight matrices
        let wx = Mat::from_fn(k, input_dim, |_, _| { let val: f64 = StandardNormal.sample(rng); val * wx_scale });
        let wh = Mat::from_fn(k, hidden_dim, |_, _| { let val: f64 = StandardNormal.sample(rng); val * wh_scale });
        let wg = Mat::from_fn(k, k, |_, _| { let val: f64 = StandardNormal.sample(rng); val * wg_scale });
        let b = DVector::zeros(k);
        
        // Initialize L factor for E = L·Lᵀ
        let mut l_factor = Mat::zeros(k, k);
        for i in 0..k {
            for j in 0..=i {
                let val: f64 = StandardNormal.sample(rng); l_factor[(i, j)] = val * 0.1;
            }
            // Ensure positive diagonal for stability
            l_factor[(i, i)] = l_factor[(i, i)].abs() + 0.01;
        }
        
        Self {
            k, input_dim, hidden_dim,
            wx, wh, wg, b,
            l_factor,
            lambda,
            phi,
        }
    }
    
    /// Core step: ψₜ₊₁ = φ(Wₓxₜ + Wₕhₜ + Eψₜ - λψₜ + b)
    pub fn step(&self, state: &CellState, input: &CellInput) -> (CellState, CollapseOut) {
        // Compute E = L·Lᵀ from factor
        let e = psd_from_factor(&self.l_factor);
        
        // Pre-activation
        let wx_term = &self.wx * &input.x;
        let wh_term = &self.wh * &state.h;
        let entangle_term = &e * &state.psi.0;
        let decohere_term = self.lambda * &state.psi.0;
        
        let pre_act = wx_term + wh_term + entangle_term - decohere_term + &self.b;
        
        // Apply nonlinearity
        let psi_next = Psi(pre_act.map(self.phi));
        
        // Collapse: α = softmax(Wₘψ)
        let logits = &self.wg * &psi_next.0;
        let alpha = softmax(&logits);
        
        // Readout and new state
        let collapse = CollapseOut::new(alpha, &psi_next);
        let h_next = state.h.clone(); // Simple passthrough for now
        
        (CellState::new(psi_next, h_next), collapse)
    }
    
    /// Get current entanglement matrix E = L·Lᵀ
    pub fn entanglement_matrix(&self) -> Mat {
        psd_from_factor(&self.l_factor)
    }
    
    /// Update L factor given gradient on E
    pub fn update_l_from_e_gradient(&mut self, grad_e: &Mat, lr: F) {
        // Simple gradient projection: ∇L ≈ ∇E · L
        let grad_l = grad_e * &self.l_factor;
        
        // Update only lower triangular part
        for i in 0..self.k {
            for j in 0..=i {
                self.l_factor[(i, j)] -= lr * grad_l[(i, j)];
            }
            // Keep diagonal positive
            if self.l_factor[(i, i)] < 0.01 {
                self.l_factor[(i, i)] = 0.01;
            }
        }
    }
}

/// Standard activation functions
pub fn tanh_activation(x: F) -> F {
    x.tanh()
}

pub fn elu_activation(x: F) -> F {
    if x >= 0.0 {
        x
    } else {
        x.exp() - 1.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rand::SeedableRng;
    
    #[test]
    fn test_cell_step() {
        let mut rng = rand_chacha::ChaCha20Rng::seed_from_u64(42);
        let cell = EntangledCell::new(4, 3, 2, 0.1, tanh_activation, &mut rng);
        
        let state = CellState::zeros(4, 2);
        let input = CellInput::from_vec(vec![1.0, -0.5, 0.0]);
        
        let (next_state, collapse) = cell.step(&state, &input);
        
        assert_eq!(next_state.psi.dim(), 4);
        assert_eq!(collapse.alpha.len(), 4);
        assert!((collapse.alpha.sum() - 1.0).abs() < 1e-10);
        assert!(collapse.entropy >= 0.0);
    }
    
    #[test]
    fn test_entanglement_psd() {
        let mut rng = rand_chacha::ChaCha20Rng::seed_from_u64(123);
        let cell = EntangledCell::new(3, 2, 1, 0.0, tanh_activation, &mut rng);
        
        let e = cell.entanglement_matrix();
        
        // Check symmetry (should be exact for L·Lᵀ)
        let diff = &e - e.transpose();
        assert!(diff.norm() < 1e-12);
        
        // Check PSD via eigenvalues
        let eigen = e.symmetric_eigen();
        for &lambda in eigen.eigenvalues.iter() {
            assert!(lambda >= -1e-12, "E should be PSD");
        }
    }
}