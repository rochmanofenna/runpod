// Standalone mathematical tests that don't depend on ENN core library
use nalgebra::{DMatrix, DVector};
use std::fs::File;
use std::io::Write;
use serde_json::json;

#[test]
fn psd_matrix_test() {
    // Test PSD property of L L^T matrices (pure linear algebra)
    println!("PSD Matrix Test (standalone):");
    
    let sizes = vec![4, 8];
    let tolerance = 1e-10;
    
    for &k in &sizes {
        println!("Testing K={}", k);
        
        // Generate random L matrix
        let mut rng = rand::thread_rng();
        let l = DMatrix::from_fn(k, k, |_, _| {
            use rand_distr::{Distribution, StandardNormal};
            let val: f64 = StandardNormal.sample(&mut rng); val * 0.1
        });
        
        // Compute E = L L^T
        let e = &l * l.transpose();
        
        // Check symmetry
        let symmetry_error = (&e - e.transpose()).amax();
        assert!(symmetry_error < 1e-12, 
                "E not symmetric: max error {}", symmetry_error);
        
        // Check eigenvalues
        let eigenvalues = e.symmetric_eigenvalues();
        let min_eig = eigenvalues.min();
        
        println!("  Min eigenvalue: {:.3e}", min_eig);
        
        assert!(min_eig >= -tolerance,
                "Negative eigenvalue {} < -{}", min_eig, tolerance);
    }
}

#[test]
fn softmax_numerics() {
    // Pure softmax implementation test
    println!("Testing softmax numerics:");
    
    let test_cases = vec![
        vec![1.0, 2.0, 3.0, 4.0],
        vec![0.0, 0.0, 0.0, 0.0],
        vec![-5.0, 10.0, -2.0, 3.0],
        vec![100.0, 100.0, 100.0, 100.0], // Large values
        vec![-100.0, -100.0, -100.0, -100.0], // Small values
    ];
    
    for (i, logits) in test_cases.iter().enumerate() {
        let alpha = pure_softmax(&DVector::from_vec(logits.clone()));
        let sum = alpha.sum();
        let error = (sum - 1.0).abs();
        
        println!("  Test case {}: sum={:.12}, error={:.3e}", i, sum, error);
        
        assert!(error < 1e-8,
                "Softmax sum {} deviates from 1 by more than 1e-8", sum);
    }
}

#[test]
fn kl_divergence_monotonicity() {
    println!("Testing KL divergence monotonicity:");
    
    let _k = 5;
    let target_idx = 2;
    let base_logits = vec![0.5, -1.0, 2.0, -0.5, 1.0];
    let scaling_factors = vec![0.5, 1.0, 2.0, 4.0];
    
    let mut kl_sequence = Vec::new();
    
    for &c in &scaling_factors {
        // Scale logits
        let scaled_logits = base_logits.iter()
            .map(|&x| x * c)
            .collect::<Vec<_>>();
        
        let alpha = pure_softmax(&DVector::from_vec(scaled_logits));
        let kl = compute_kl_to_onehot(&alpha, target_idx);
        
        kl_sequence.push(kl);
        
        println!("  c={:.1}: KL={:.6}, α[target]={:.6}", 
                 c, kl, alpha[target_idx]);
    }
    
    // Check monotonicity: KL should decrease as c increases
    for i in 1..kl_sequence.len() {
        assert!(kl_sequence[i] < kl_sequence[i-1] + 1e-10,
                "KL not decreasing: {} -> {} at c={} -> {}",
                kl_sequence[i-1], kl_sequence[i],
                scaling_factors[i-1], scaling_factors[i]);
    }
    
    // Save results
    let results = json!({
        "kl_sequence": kl_sequence,
        "scaling_factors": scaling_factors,
    });
    
    std::fs::create_dir_all("runs").ok();
    let mut file = File::create("runs/enn_kl_test.json").unwrap();
    write!(file, "{}", serde_json::to_string(&results).unwrap()).unwrap();
    
    println!("  ✓ KL monotonically decreases with scaling");
}

// Pure implementations without ENN dependencies
fn pure_softmax(logits: &DVector<f64>) -> DVector<f64> {
    let max_logit = logits.max();
    let exp_logits = logits.map(|x| (x - max_logit).exp());
    let sum_exp = exp_logits.sum();
    exp_logits / sum_exp
}

fn compute_kl_to_onehot(alpha: &DVector<f64>, target_idx: usize) -> f64 {
    let eps = 1e-15; // Avoid log(0)
    -alpha[target_idx].max(eps).ln()
}