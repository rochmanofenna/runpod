use nalgebra::{DMatrix};
use rand::thread_rng;
use rand_distr::{Distribution, Normal};

#[test]
fn psd_e() {
    // Test PSD property of entanglement matrix E = L L^T
    let sizes = vec![4, 8, 16];
    let num_trials = 10;
    let tolerance = 1e-10;
    
    println!("PSD Entanglement Matrix Test:");
    println!("Testing E = L L^T parametrization");
    
    for &k in &sizes {
        println!("\nTesting K={}", k);
        let mut min_eigenvalue_overall = f64::INFINITY;
        
        for trial in 0..num_trials {
            // Generate random L matrix
            let l = generate_random_l(k);
            
            // Compute E = L L^T
            let e = &l * l.transpose();
            
            // Check symmetry
            let symmetry_error = (&e - e.transpose()).max();
            assert!(symmetry_error < 1e-12, 
                    "E not symmetric: max error {}", symmetry_error);
            
            // Compute eigenvalues
            let eigenvalues = e.symmetric_eigenvalues();
            let min_eig: f64 = eigenvalues.min();
            let max_eig = eigenvalues.max();
            
            if min_eig < min_eigenvalue_overall {
                min_eigenvalue_overall = min_eig;
            }
            
            // Check PSD property
            assert!(min_eig >= -tolerance,
                    "Negative eigenvalue {} < -{} at trial {} for K={}",
                    min_eig, tolerance, trial, k);
            
            if trial == 0 {
                println!("  Trial {}: min_eig={:.3e}, max_eig={:.3e}, cond={:.3e}",
                        trial, min_eig, max_eig, max_eig / min_eig.max(1e-15));
            }
        }
        
        println!("  Overall min eigenvalue: {:.3e}", min_eigenvalue_overall);
    }
    
    // Test edge case: rank-deficient L
    test_rank_deficient_case();
}

fn generate_random_l(k: usize) -> DMatrix<f64> {
    let mut rng = thread_rng();
    let normal = Normal::new(0.0, 1.0).unwrap();
    
    DMatrix::from_fn(k, k, |_, _| normal.sample(&mut rng))
}

fn test_rank_deficient_case() {
    println!("\nTesting rank-deficient case:");
    let k = 8;
    let rank = 3;
    
    // Create rank-deficient L
    let mut l = DMatrix::zeros(k, k);
    let mut rng = thread_rng();
    let normal = Normal::new(0.0, 1.0).unwrap();
    
    // Only fill first 'rank' columns
    for i in 0..k {
        for j in 0..rank {
            l[(i, j)] = normal.sample(&mut rng);
        }
    }
    
    // Compute E = L L^T
    let e = &l * l.transpose();
    
    // Check eigenvalues
    let eigenvalues = e.symmetric_eigenvalues();
    let min_eig: f64 = eigenvalues.min();
    let num_zero_eigs = eigenvalues.iter()
        .filter(|&&x| x.abs() < 1e-10)
        .count();
    
    println!("  Rank-deficient L (rank {}): min_eig={:.3e}", rank, min_eig);
    println!("  Number of near-zero eigenvalues: {}", num_zero_eigs);
    println!("  Expected near-zero eigenvalues: {}", k - rank);
    
    assert!(min_eig >= -1e-10,
            "Negative eigenvalue {} in rank-deficient case", min_eig);
}

#[test]
fn psd_e_dynamics() {
    // Test that PSD property is preserved under typical update operations
    let k = 6;
    let lr = 0.01;
    let steps = 100;
    
    println!("\nPSD preservation under gradient updates:");
    
    // Initialize L
    let mut l = generate_random_l(k);
    
    for step in 0..steps {
        // Compute E = L L^T
        let e = &l * l.transpose();
        
        // Check minimum eigenvalue
        let min_eig = e.symmetric_eigenvalues().min();
        
        if step % 20 == 0 {
            println!("  Step {}: min_eig={:.3e}", step, min_eig);
        }
        
        assert!(min_eig >= -1e-10,
                "Negative eigenvalue {} at step {}", min_eig, step);
        
        // Simulate gradient update
        let grad_l = DMatrix::from_fn(k, k, |_, _| {
            let mut rng = thread_rng();
            Normal::new(0.0, 0.1).unwrap().sample(&mut rng)
        });
        
        l -= lr * grad_l;
    }
}