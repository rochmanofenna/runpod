pub mod humanoid_maze;
pub mod ant_soccer;
pub mod puzzle;

pub use humanoid_maze::*;
pub use ant_soccer::*;
pub use puzzle::*;