use crate::types::{F, Psi, CellState, CellInput, CollapseOut};
use crate::cell::EntangledCell;
use nalgebra::{DVector, DMatrix};

/// Stochastic calculus interpretation
#[derive(Copy, Clone, Debug, PartialEq)]
pub enum Calc {
    Ito,           // Martingale calculus, discrete-time intuition
    Stratonovich,  // Chain rule preservation, smooth-noise limit
}

/// Diffusion head for stochastic ENN dynamics
pub trait DiffusionHead: Send + Sync {
    /// Diffusion matrix G_θ(t,ψ,x,h): K × m
    /// Maps m-dimensional noise dW to K-dimensional state increment
    fn g_sigma(&self, t: F, psi: &Psi, x: &DVector<F>, h: &DVector<F>) -> DMatrix<F>;
    
    /// Optional Jacobian ∂G/∂ψ for Itô↔Stratonovich drift correction
    fn g_sigma_jacobian(&self, _t: F, _psi: &Psi, _x: &DVector<F>, _h: &DVector<F>) -> Option<Vec<DMatrix<F>>> {
        None
    }
    
    /// Number of noise dimensions
    fn noise_dim(&self, t: F, psi: &Psi, x: &DVector<F>, h: &DVector<F>) -> usize {
        self.g_sigma(t, psi, x, h).ncols()
    }
}

/// Simple diagonal diffusion head (independent noise per latent state)
pub struct DiagonalDiffusion {
    pub sigma: F,  // Constant volatility
}

impl DiagonalDiffusion {
    pub fn new(sigma: F) -> Self {
        Self { sigma }
    }
}

impl DiffusionHead for DiagonalDiffusion {
    fn g_sigma(&self, _t: F, psi: &Psi, _x: &DVector<F>, _h: &DVector<F>) -> DMatrix<F> {
        let k = psi.dim();
        DMatrix::from_diagonal_element(k, k, self.sigma)
    }
    
    fn g_sigma_jacobian(&self, _t: F, psi: &Psi, _x: &DVector<F>, _h: &DVector<F>) -> Option<Vec<DMatrix<F>>> {
        let k = psi.dim();
        // For diagonal constant σ, all Jacobians are zero
        Some(vec![DMatrix::zeros(k, k); k])
    }
}

/// Itô-Stratonovich drift correction helper
pub fn stratonovich_drift_correction(
    t: F,
    psi: &Psi, 
    x: &DVector<F>,
    h: &DVector<F>,
    diffusion: &impl DiffusionHead
) -> Option<DVector<F>> {
    let jacs = diffusion.g_sigma_jacobian(t, psi, x, h)?;
    let g_sigma = diffusion.g_sigma(t, psi, x, h);
    let k = psi.dim();
    
    let mut correction = DVector::zeros(k);
    
    // For each noise dimension j
    for (j, jac_j) in jacs.iter().enumerate() {
        // G_j is the j-th column of G
        let g_j = g_sigma.column(j);
        // correction += jac_j * G_j  
        correction += jac_j * &g_j;
    }
    
    Some(0.5 * correction)
}

/// Euler-Maruyama step for stochastic ENN (Itô interpretation)
pub fn step_em_ito(
    cell: &EntangledCell,
    diffusion: &impl DiffusionHead,
    t: F,
    dt: F,
    dw: &DVector<F>,
    state: &CellState,
    input: &CellInput,
) -> (CellState, CollapseOut) {
    // Standard ENN step provides drift
    let (mut next_state, collapse) = cell.step(state, input);
    
    // Add stochastic increment: ψ += G(t,ψ,x,h) * dW
    let g_matrix = diffusion.g_sigma(t, &state.psi, &input.x, &state.h);
    let noise_increment = g_matrix * dw;
    
    next_state.psi.0 += noise_increment;
    
    (next_state, collapse)
}

/// Heun midpoint step for stochastic ENN (Stratonovich interpretation)
pub fn step_heun_stratonovich(
    cell: &EntangledCell,
    diffusion: &impl DiffusionHead,
    t: F,
    dt: F,
    dw: &DVector<F>,
    state: &CellState,
    input: &CellInput,
) -> (CellState, CollapseOut) {
    // Predictor step
    let (state_pred, _) = cell.step(state, input);
    let g0 = diffusion.g_sigma(t, &state.psi, &input.x, &state.h);
    
    // Apply noise to predictor
    let mut state_tilde = state_pred;
    state_tilde.psi.0 += &g0 * dw;
    
    // Corrector step  
    let (state_corr, _) = cell.step(&state_tilde, input);
    let g1 = diffusion.g_sigma(t + dt, &state_tilde.psi, &input.x, &state_tilde.h);
    
    // Midpoint diffusion coefficient
    let g_mid = 0.5 * (g0 + g1);
    
    // Final step with midpoint diffusion
    let (mut final_state, final_collapse) = cell.step(state, input);
    final_state.psi.0 += g_mid * dw;
    
    (final_state, final_collapse)
}

/// Convert Stratonovich to Itô via drift correction
pub fn step_stratonovich_as_ito(
    cell: &EntangledCell,
    diffusion: &impl DiffusionHead,
    t: F,
    dt: F,
    dw: &DVector<F>,
    state: &CellState,
    input: &CellInput,
) -> (CellState, CollapseOut) {
    // Get base step
    let (mut next_state, collapse) = cell.step(state, input);
    
    // Apply Stratonovich drift correction if Jacobians available
    if let Some(correction) = stratonovich_drift_correction(t, &state.psi, &input.x, &state.h, diffusion) {
        // μ° = μ - 0.5 * correction (Stratonovich drift)
        next_state.psi.0 -= correction * dt;
    }
    
    // Add Itô noise increment
    let g_matrix = diffusion.g_sigma(t, &state.psi, &input.x, &state.h);
    next_state.psi.0 += g_matrix * dw;
    
    (next_state, collapse)
}

#[cfg(test)]
mod tests {
    use super::*;
    use rand::SeedableRng;
    use crate::cell::tanh_activation;
    use rand_distr::{Distribution, StandardNormal};
    
    #[test]
    fn test_diagonal_diffusion() {
        let diff = DiagonalDiffusion::new(0.1);
        let psi = Psi::new(vec![1.0, 2.0, 3.0]);
        let x = DVector::from_vec(vec![0.5]);
        let h = DVector::from_vec(vec![0.0]);
        
        let g = diff.g_sigma(0.0, &psi, &x, &h);
        assert_eq!(g.shape(), (3, 3));
        
        // Should be diagonal with σ = 0.1
        for i in 0..3 {
            for j in 0..3 {
                if i == j {
                    assert_eq!(g[(i, j)], 0.1);
                } else {
                    assert_eq!(g[(i, j)], 0.0);
                }
            }
        }
    }
    
    #[test]
    fn test_ito_stratonovich_equivalence() {
        let mut rng = rand_chacha::ChaCha20Rng::seed_from_u64(789);
        let cell = EntangledCell::new(3, 2, 1, 0.0, tanh_activation, &mut rng);
        let diff = DiagonalDiffusion::new(0.05);
        
        let state = CellState::new(
            Psi::new(vec![0.1, 0.2, -0.1]),
            DVector::zeros(1)
        );
        let input = CellInput::new(vec![1.0, -0.5]);
        
        // Generate same noise for both methods
        let dt = 0.01;
        let dw: DVector<F> = DVector::from_iterator(3, 
            (0..3).map(|_| StandardNormal.sample(&mut rng) * dt.sqrt())
        );
        
        // Compare Itô EM vs Stratonovich Heun (should converge as dt→0)
        let (state_ito, _) = step_em_ito(&cell, &diff, 0.0, dt, &dw, &state, &input);
        let (state_strat, _) = step_heun_stratonovich(&cell, &diff, 0.0, dt, &dw, &state, &input);
        
        // For small dt and simple diffusion, should be close
        let diff_norm = (&state_ito.psi.0 - &state_strat.psi.0).norm();
        assert!(diff_norm < 0.1, "Itô and Stratonovich should be close for small dt");
    }
}