use crate::types::{F, Mat, Psi};
use crate::collapse::kl_one_hot;
use nalgebra::DVector;

/// Create PSD matrix from lower triangular factor: E = L·Lᵀ
pub fn psd_from_factor(l: &Mat) -> Mat {
    l * l.transpose()
}

/// Regularizer configuration
#[derive(Clone, Debug)]
pub struct Regularizers {
    pub beta_symmetry: F,    // Weight for ‖E - Eᵀ‖²_F
    pub gamma_collapse: F,   // Weight for KL(α ‖ one-hot)
    pub eta_norm: F,         // Weight for ‖ψ‖²
}

impl Regularizers {
    pub fn new(beta: F, gamma: F, eta: F) -> Self {
        Self {
            beta_symmetry: beta,
            gamma_collapse: gamma,
            eta_norm: eta,
        }
    }
    
    pub fn default() -> Self {
        Self::new(0.0, 0.1, 0.001)  // No symmetry penalty if using L·Lᵀ
    }
    
    /// Symmetry penalty: ‖E - Eᵀ‖²_F
    pub fn symmetry_loss(&self, e: &Mat) -> F {
        if self.beta_symmetry <= 0.0 {
            return 0.0;
        }
        
        let antisym = e - e.transpose();
        self.beta_symmetry * antisym.norm_squared()
    }
    
    /// Collapse penalty: KL(α ‖ uniform)
    pub fn collapse_loss(&self, alpha: &DVector<F>) -> F {
        if self.gamma_collapse <= 0.0 {
            return 0.0;
        }
        
        self.gamma_collapse * kl_one_hot(alpha)
    }
    
    /// Norm penalty: ‖ψ‖²
    pub fn norm_loss(&self, psi: &Psi) -> F {
        if self.eta_norm <= 0.0 {
            return 0.0;
        }
        
        self.eta_norm * psi.norm_squared()
    }
    
    /// Total regularization loss
    pub fn total_loss(&self, e: &Mat, alpha: &DVector<F>, psi: &Psi) -> F {
        self.symmetry_loss(e) + self.collapse_loss(alpha) + self.norm_loss(psi)
    }
}

/// Collapse schedule: gradually increase γ during training
#[derive(Clone, Debug)]
pub struct CollapseSchedule {
    pub gamma_start: F,
    pub gamma_end: F,
    pub warmup_steps: usize,
}

impl CollapseSchedule {
    pub fn new(gamma_start: F, gamma_end: F, warmup_steps: usize) -> Self {
        Self { gamma_start, gamma_end, warmup_steps }
    }
    
    pub fn default() -> Self {
        Self::new(0.01, 0.5, 1000)
    }
    
    pub fn get_gamma(&self, step: usize) -> F {
        if step >= self.warmup_steps {
            self.gamma_end
        } else {
            let t = step as F / self.warmup_steps as F;
            self.gamma_start + (self.gamma_end - self.gamma_start) * t
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_psd_from_factor() {
        let k = 3;
        let mut l = Mat::zeros(k, k);
        l[(0, 0)] = 1.0;
        l[(1, 0)] = 0.5;
        l[(1, 1)] = 1.0;
        l[(2, 0)] = 0.3;
        l[(2, 1)] = 0.2;
        l[(2, 2)] = 1.0;
        
        let e = psd_from_factor(&l);
        
        // Check symmetry
        let diff = &e - e.transpose();
        assert!(diff.norm() < 1e-12);
        
        // Check PSD
        let eigen = e.symmetric_eigen();
        for &lambda in eigen.eigenvalues.iter() {
            assert!(lambda >= -1e-12);
        }
    }
    
    #[test]
    fn test_collapse_schedule() {
        let schedule = CollapseSchedule::new(0.0, 1.0, 100);
        
        assert_eq!(schedule.get_gamma(0), 0.0);
        assert_eq!(schedule.get_gamma(50), 0.5);
        assert_eq!(schedule.get_gamma(100), 1.0);
        assert_eq!(schedule.get_gamma(200), 1.0);
    }
}