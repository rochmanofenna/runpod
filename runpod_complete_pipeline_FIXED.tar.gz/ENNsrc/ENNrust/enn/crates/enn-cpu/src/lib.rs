use enn_core::{EntangledCell, CellState, CellInput, types::{Psi, CollapseOut}};
use enn_core::regularizers::Regularizers;
use nalgebra::{DVector, DMatrix};
use rayon::prelude::*;

/// Batch input for parallel processing
#[derive(Clone, Debug)]
pub struct BatchInput {
    pub sequences: Vec<Vec<DVector<f64>>>, // [batch_size][seq_len][input_dim]
}

impl BatchInput {
    pub fn new(sequences: Vec<Vec<DVector<f64>>>) -> Self {
        Self { sequences }
    }
    
    pub fn batch_size(&self) -> usize {
        self.sequences.len()
    }
    
    pub fn seq_len(&self) -> usize {
        self.sequences.first().map(|s| s.len()).unwrap_or(0)
    }
    
    pub fn input_dim(&self) -> usize {
        self.sequences.first()
            .and_then(|s| s.first())
            .map(|v| v.len())
            .unwrap_or(0)
    }
}

/// Batch state for parallel processing
#[derive(Clone, Debug)]
pub struct BatchState {
    pub psi_batch: Vec<Psi>,               // [batch_size][k]
    pub h_batch: Vec<DVector<f64>>,        // [batch_size][hidden_dim]
}

impl BatchState {
    pub fn zeros(batch_size: usize, k: usize, hidden_dim: usize) -> Self {
        Self {
            psi_batch: (0..batch_size).map(|_| Psi::new(k)).collect(),
            h_batch: (0..batch_size).map(|_| DVector::zeros(hidden_dim)).collect(),
        }
    }
    
    pub fn from_states(states: Vec<CellState>) -> Self {
        Self {
            psi_batch: states.iter().map(|s| s.psi.clone()).collect(),
            h_batch: states.iter().map(|s| s.h.clone()).collect(),
        }
    }
    
    pub fn to_states(&self) -> Vec<CellState> {
        self.psi_batch.iter()
            .zip(self.h_batch.iter())
            .map(|(psi, h)| CellState::new(psi.clone(), h.clone()))
            .collect()
    }
    
    pub fn batch_size(&self) -> usize {
        self.psi_batch.len()
    }
}

/// Batch output containing all sequence processing results
#[derive(Clone, Debug)]
pub struct BatchOutput {
    pub collapses: Vec<Vec<CollapseOut>>,  // [batch_size][seq_len]
    pub final_states: BatchState,
    pub sequence_predictions: Vec<Vec<f64>>, // [batch_size][seq_len]
    pub sequence_entropies: Vec<Vec<f64>>,   // [batch_size][seq_len]
}

impl BatchOutput {
    pub fn batch_size(&self) -> usize {
        self.collapses.len()
    }
    
    pub fn seq_len(&self) -> usize {
        self.collapses.first().map(|s| s.len()).unwrap_or(0)
    }
}

/// CPU-optimized batched ENN for parallel sequence processing
pub struct BatchedENN {
    pub cell: EntangledCell,
    pub regularizers: Regularizers,
}

impl BatchedENN {
    pub fn new(cell: EntangledCell, regularizers: Regularizers) -> Self {
        Self { cell, regularizers }
    }
    
    /// Forward pass through entire batch of sequences in parallel
    pub fn forward(&self, batch_input: &BatchInput, initial_states: &BatchState) -> BatchOutput {
        let batch_size = batch_input.batch_size();
        let _seq_len = batch_input.seq_len();
        
        // Process each sequence in parallel
        let results: Vec<_> = batch_input.sequences
            .par_iter()
            .zip(initial_states.psi_batch.par_iter())
            .zip(initial_states.h_batch.par_iter())
            .map(|((sequence, psi), h)| {
                self.forward_single_sequence(
                    sequence, 
                    &CellState::new(psi.clone(), h.clone())
                )
            })
            .collect();
        
        // Reorganize results into batch format
        let mut collapses = Vec::with_capacity(batch_size);
        let mut final_psi_batch = Vec::with_capacity(batch_size);
        let mut final_h_batch = Vec::with_capacity(batch_size);
        let mut sequence_predictions = Vec::with_capacity(batch_size);
        let mut sequence_entropies = Vec::with_capacity(batch_size);
        
        for (seq_collapses, final_state) in results {
            collapses.push(seq_collapses.clone());
            final_psi_batch.push(final_state.psi.clone());
            final_h_batch.push(final_state.h.clone());
            
            // Extract predictions and entropies
            let predictions: Vec<f64> = seq_collapses.iter().map(|c| c.z).collect();
            let entropies: Vec<f64> = seq_collapses.iter().map(|c| c.entropy).collect();
            
            sequence_predictions.push(predictions);
            sequence_entropies.push(entropies);
        }
        
        BatchOutput {
            collapses,
            final_states: BatchState {
                psi_batch: final_psi_batch,
                h_batch: final_h_batch,
            },
            sequence_predictions,
            sequence_entropies,
        }
    }
    
    /// Forward pass through a single sequence
    fn forward_single_sequence(
        &self, 
        sequence: &[DVector<f64>], 
        initial_state: &CellState
    ) -> (Vec<CollapseOut>, CellState) {
        let mut state = initial_state.clone();
        let mut collapses = Vec::with_capacity(sequence.len());
        
        for input_vec in sequence {
            let input = CellInput::from_vec(input_vec.data.as_vec().clone());
            let (next_state, collapse) = self.cell.step(&state, &input);
            
            collapses.push(collapse);
            state = next_state;
        }
        
        (collapses, state)
    }
    
    /// Batch-parallel regularization loss computation
    pub fn batch_regularization_loss(&self, batch_output: &BatchOutput) -> f64 {
        let batch_size = batch_output.batch_size();
        if batch_size == 0 { return 0.0; }
        
        let e_matrix = self.cell.entanglement_matrix();
        
        // Parallel computation of regularization losses
        let total_loss: f64 = batch_output.collapses
            .par_iter()
            .zip(batch_output.final_states.psi_batch.par_iter())
            .map(|(collapses, final_psi)| {
                let mut sequence_loss = 0.0;
                
                // Accumulate losses over sequence
                for collapse in collapses {
                    sequence_loss += self.regularizers.total_loss(&e_matrix, &collapse.alpha, final_psi);
                }
                
                sequence_loss
            })
            .sum();
        
        total_loss / batch_size as f64
    }
    
    /// Compute batch statistics for analysis
    pub fn compute_batch_statistics(&self, batch_output: &BatchOutput) -> BatchStatistics {
        let batch_size = batch_output.batch_size();
        let seq_len = batch_output.seq_len();
        
        if batch_size == 0 {
            return BatchStatistics::default();
        }
        
        // Parallel computation of statistics
        let sequence_stats: Vec<_> = batch_output.sequence_predictions
            .par_iter()
            .zip(batch_output.sequence_entropies.par_iter())
            .map(|(predictions, entropies)| {
                SequenceStatistics {
                    mean_prediction: predictions.iter().sum::<f64>() / predictions.len() as f64,
                    std_prediction: {
                        let mean = predictions.iter().sum::<f64>() / predictions.len() as f64;
                        let variance = predictions.iter()
                            .map(|&x| (x - mean).powi(2))
                            .sum::<f64>() / predictions.len() as f64;
                        variance.sqrt()
                    },
                    mean_entropy: entropies.iter().sum::<f64>() / entropies.len() as f64,
                    max_entropy: entropies.iter().fold(f64::NEG_INFINITY, |a, &b| a.max(b)),
                    min_entropy: entropies.iter().fold(f64::INFINITY, |a, &b| a.min(b)),
                }
            })
            .collect();
        
        // Aggregate across batch
        let global_mean_prediction = sequence_stats.iter()
            .map(|s| s.mean_prediction)
            .sum::<f64>() / batch_size as f64;
        
        let global_mean_entropy = sequence_stats.iter()
            .map(|s| s.mean_entropy)
            .sum::<f64>() / batch_size as f64;
        
        let global_max_entropy = sequence_stats.iter()
            .map(|s| s.max_entropy)
            .fold(f64::NEG_INFINITY, |a, b| a.max(b));
        
        let global_min_entropy = sequence_stats.iter()
            .map(|s| s.min_entropy)
            .fold(f64::INFINITY, |a, b| a.min(b));
        
        BatchStatistics {
            batch_size,
            seq_len,
            sequence_stats,
            global_mean_prediction,
            global_mean_entropy,
            global_max_entropy,
            global_min_entropy,
        }
    }
    
    /// Memory-efficient chunked processing for very large batches
    pub fn forward_chunked(
        &self, 
        batch_input: &BatchInput, 
        initial_states: &BatchState, 
        chunk_size: usize
    ) -> BatchOutput {
        let batch_size = batch_input.batch_size();
        
        let mut all_collapses = Vec::with_capacity(batch_size);
        let mut all_final_states = BatchState {
            psi_batch: Vec::with_capacity(batch_size),
            h_batch: Vec::with_capacity(batch_size),
        };
        let mut all_predictions = Vec::with_capacity(batch_size);
        let mut all_entropies = Vec::with_capacity(batch_size);
        
        // Process in chunks
        for chunk_start in (0..batch_size).step_by(chunk_size) {
            let chunk_end = (chunk_start + chunk_size).min(batch_size);
            
            let chunk_sequences = batch_input.sequences[chunk_start..chunk_end].to_vec();
            let chunk_psi = initial_states.psi_batch[chunk_start..chunk_end].to_vec();
            let chunk_h = initial_states.h_batch[chunk_start..chunk_end].to_vec();
            
            let chunk_input = BatchInput::new(chunk_sequences);
            let chunk_initial = BatchState {
                psi_batch: chunk_psi,
                h_batch: chunk_h,
            };
            
            let chunk_output = self.forward(&chunk_input, &chunk_initial);
            
            // Accumulate results
            all_collapses.extend(chunk_output.collapses);
            all_final_states.psi_batch.extend(chunk_output.final_states.psi_batch);
            all_final_states.h_batch.extend(chunk_output.final_states.h_batch);
            all_predictions.extend(chunk_output.sequence_predictions);
            all_entropies.extend(chunk_output.sequence_entropies);
        }
        
        BatchOutput {
            collapses: all_collapses,
            final_states: all_final_states,
            sequence_predictions: all_predictions,
            sequence_entropies: all_entropies,
        }
    }
}

/// Statistics for a single sequence
#[derive(Clone, Debug)]
pub struct SequenceStatistics {
    pub mean_prediction: f64,
    pub std_prediction: f64,
    pub mean_entropy: f64,
    pub max_entropy: f64,
    pub min_entropy: f64,
}

/// Comprehensive batch statistics
#[derive(Clone, Debug)]
pub struct BatchStatistics {
    pub batch_size: usize,
    pub seq_len: usize,
    pub sequence_stats: Vec<SequenceStatistics>,
    pub global_mean_prediction: f64,
    pub global_mean_entropy: f64,
    pub global_max_entropy: f64,
    pub global_min_entropy: f64,
}

impl Default for BatchStatistics {
    fn default() -> Self {
        Self {
            batch_size: 0,
            seq_len: 0,
            sequence_stats: Vec::new(),
            global_mean_prediction: 0.0,
            global_mean_entropy: 0.0,
            global_max_entropy: f64::NEG_INFINITY,
            global_min_entropy: f64::INFINITY,
        }
    }
}

/// Advanced batch operations for performance optimization
pub struct BatchOps;

impl BatchOps {
    /// Parallel matrix operations for batch weight updates
    pub fn parallel_weight_update(
        weights: &mut DMatrix<f64>,
        gradients: &[DMatrix<f64>],
        learning_rate: f64,
    ) {
        let (rows, cols) = weights.shape();
        
        // Sequential update since nalgebra doesn't support par_iter_mut for DMatrix
        for i in 0..rows {
            for j in 0..cols {
                // Accumulate gradients from batch
                let total_grad: f64 = gradients.iter()
                    .map(|grad| grad[(i, j)])
                    .sum();
                
                let avg_grad = total_grad / gradients.len() as f64;
                weights[(i, j)] -= learning_rate * avg_grad;
            }
        }
    }
    
    /// Memory-efficient attention computation across batch
    pub fn batch_attention_weights(
        batch_logits: &[DVector<f64>],
    ) -> Vec<DVector<f64>> {
        batch_logits.par_iter()
            .map(|logits| {
                // Stable softmax
                let max_logit = logits.max();
                let exp_logits = logits.map(|x| (x - max_logit).exp());
                let sum_exp = exp_logits.sum();
                exp_logits / sum_exp
            })
            .collect()
    }
    
    /// Vectorized entropy computation
    pub fn batch_entropy(alpha_batch: &[DVector<f64>]) -> Vec<f64> {
        alpha_batch.par_iter()
            .map(|alpha| {
                -alpha.iter()
                    .filter(|&&a| a > 1e-12)
                    .map(|&a| a * a.ln())
                    .sum::<f64>()
            })
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use enn_core::cell::tanh_activation;
    use rand::SeedableRng;
    
    #[test]
    fn test_batch_input() {
        let sequences = vec![
            vec![DVector::from_vec(vec![1.0, 2.0]), DVector::from_vec(vec![3.0, 4.0])],
            vec![DVector::from_vec(vec![5.0, 6.0]), DVector::from_vec(vec![7.0, 8.0])],
        ];
        
        let batch = BatchInput::new(sequences);
        
        assert_eq!(batch.batch_size(), 2);
        assert_eq!(batch.seq_len(), 2);
        assert_eq!(batch.input_dim(), 2);
    }
    
    #[test]
    fn test_batch_state() {
        let state = BatchState::zeros(3, 4, 2);
        
        assert_eq!(state.batch_size(), 3);
        assert_eq!(state.psi_batch.len(), 3);
        assert_eq!(state.h_batch.len(), 3);
        
        for psi in &state.psi_batch {
            assert_eq!(psi.dim(), 4);
        }
        
        for h in &state.h_batch {
            assert_eq!(h.len(), 2);
        }
    }
    
    #[test]
    fn test_batched_enn_forward() {
        let mut rng = rand_chacha::ChaCha20Rng::seed_from_u64(42);
        
        let k = 4;
        let input_dim = 2;
        let hidden_dim = 3;
        let cell = EntangledCell::new(k, input_dim, hidden_dim, 0.1, tanh_activation, &mut rng);
        let regularizers = Regularizers::default();
        
        let batched_enn = BatchedENN::new(cell, regularizers);
        
        // Create test batch
        let sequences = vec![
            vec![DVector::from_vec(vec![0.1, 0.2]), DVector::from_vec(vec![0.3, 0.4])],
            vec![DVector::from_vec(vec![0.5, 0.6]), DVector::from_vec(vec![0.7, 0.8])],
        ];
        let batch_input = BatchInput::new(sequences);
        let initial_states = BatchState::zeros(2, k, hidden_dim);
        
        let output = batched_enn.forward(&batch_input, &initial_states);
        
        assert_eq!(output.batch_size(), 2);
        assert_eq!(output.seq_len(), 2);
        assert_eq!(output.collapses.len(), 2);
        assert_eq!(output.sequence_predictions.len(), 2);
        
        // Verify all sequences processed
        for (i, collapses) in output.collapses.iter().enumerate() {
            assert_eq!(collapses.len(), 2, "Sequence {} should have 2 timesteps", i);
            for collapse in collapses {
                assert!((collapse.alpha.sum() - 1.0).abs() < 1e-10, "Alpha should sum to 1");
                assert!(collapse.entropy >= 0.0, "Entropy should be non-negative");
            }
        }
    }
    
    #[test]
    fn test_batch_statistics() {
        let mut rng = rand_chacha::ChaCha20Rng::seed_from_u64(42);
        
        let cell = EntangledCell::new(3, 1, 2, 0.05, tanh_activation, &mut rng);
        let regularizers = Regularizers::default();
        let batched_enn = BatchedENN::new(cell, regularizers);
        
        let sequences = vec![
            vec![DVector::from_vec(vec![1.0]), DVector::from_vec(vec![-1.0])],
        ];
        let batch_input = BatchInput::new(sequences);
        let initial_states = BatchState::zeros(1, 3, 2);
        
        let output = batched_enn.forward(&batch_input, &initial_states);
        let stats = batched_enn.compute_batch_statistics(&output);
        
        assert_eq!(stats.batch_size, 1);
        assert_eq!(stats.seq_len, 2);
        assert_eq!(stats.sequence_stats.len(), 1);
        
        assert!(stats.global_mean_entropy.is_finite());
        assert!(stats.global_max_entropy >= stats.global_min_entropy);
    }
}