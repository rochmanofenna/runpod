use enn_core::{F, Mat};
use nalgebra::DVector;
use std::collections::HashMap;

/// Parameter update abstraction
pub trait Optimizer {
    fn step(&mut self, params: &mut ParamDict, grads: &ParamDict);
    fn zero_grad(&mut self);
}

/// Simple parameter dictionary
pub type ParamDict = HashMap<String, Param>;

#[derive(Clone, Debug)]
pub enum Param {
    Vector(DVector<F>),
    Matrix(Mat),
}

impl Param {
    pub fn add_scaled(&mut self, grad: &Param, lr: F) {
        match (self, grad) {
            (Param::Vector(v), Param::Vector(g)) => *v -= lr * g,
            (Param::Matrix(m), Param::Matrix(g)) => *m -= lr * g,
            _ => panic!("Parameter type mismatch"),
        }
    }
}

/// AdamW optimizer with decoupled weight decay
pub struct AdamW {
    pub lr: F,
    pub betas: (F, F),
    pub eps: F,
    pub weight_decay: F,
    
    // Momentum states
    m: HashMap<String, Param>,
    v: HashMap<String, Param>,
    t: usize,
}

impl AdamW {
    pub fn new(lr: F, weight_decay: F) -> Self {
        Self {
            lr,
            betas: (0.9, 0.999),
            eps: 1e-8,
            weight_decay,
            m: HashMap::new(),
            v: HashMap::new(),
            t: 0,
        }
    }
    
    fn init_state(&mut self, name: &str, param: &Param) {
        if !self.m.contains_key(name) {
            let zeros = match param {
                Param::Vector(p) => Param::Vector(DVector::zeros(p.len())),
                Param::Matrix(p) => Param::Matrix(Mat::zeros(p.nrows(), p.ncols())),
            };
            self.m.insert(name.to_string(), zeros.clone());
            self.v.insert(name.to_string(), zeros);
        }
    }
}

impl Optimizer for AdamW {
    fn step(&mut self, params: &mut ParamDict, grads: &ParamDict) {
        self.t += 1;
        let t = self.t as F;
        
        let lr_t = self.lr * (1.0 - self.betas.1.powf(t)).sqrt() / (1.0 - self.betas.0.powf(t));
        
        for (name, param) in params.iter_mut() {
            if let Some(grad) = grads.get(name) {
                self.init_state(name, param);
                
                let m = self.m.get_mut(name).unwrap();
                let v = self.v.get_mut(name).unwrap();
                
                // Update biased moments
                match (m, v, grad) {
                    (Param::Vector(m_vec), Param::Vector(v_vec), Param::Vector(g_vec)) => {
                        *m_vec = self.betas.0 * &*m_vec + (1.0 - self.betas.0) * g_vec;
                        *v_vec = self.betas.1 * &*v_vec + (1.0 - self.betas.1) * g_vec.component_mul(g_vec);
                        
                        if let Param::Vector(p_vec) = param {
                            // AdamW update with decoupled weight decay
                            let update = m_vec.component_div(&v_vec.map(|x| x.sqrt() + self.eps));
                            *p_vec -= lr_t * &update + self.weight_decay * &*p_vec;
                        }
                    }
                    (Param::Matrix(m_mat), Param::Matrix(v_mat), Param::Matrix(g_mat)) => {
                        *m_mat = self.betas.0 * &*m_mat + (1.0 - self.betas.0) * g_mat;
                        *v_mat = self.betas.1 * &*v_mat + (1.0 - self.betas.1) * g_mat.component_mul(g_mat);
                        
                        if let Param::Matrix(p_mat) = param {
                            // AdamW update with decoupled weight decay
                            let update = m_mat.zip_map(v_mat, |m_ij, v_ij| {
                                m_ij / (v_ij.sqrt() + self.eps)
                            });
                            *p_mat -= lr_t * &update + self.weight_decay * &*p_mat;
                        }
                    }
                    _ => panic!("Parameter type mismatch in AdamW"),
                }
            }
        }
    }
    
    fn zero_grad(&mut self) {
        // Gradients are stored externally, so nothing to do here
    }
}

/// Learning rate schedulers
pub trait LRScheduler {
    fn get_lr(&self, step: usize) -> F;
}

pub struct CosineSchedule {
    pub lr_start: F,
    pub lr_end: F,
    pub warmup_steps: usize,
    pub total_steps: usize,
}

impl CosineSchedule {
    pub fn new(lr_start: F, lr_end: F, warmup_steps: usize, total_steps: usize) -> Self {
        Self { lr_start, lr_end, warmup_steps, total_steps }
    }
}

impl LRScheduler for CosineSchedule {
    fn get_lr(&self, step: usize) -> F {
        if step < self.warmup_steps {
            // Linear warmup
            let t = step as F / self.warmup_steps as F;
            self.lr_start * t
        } else if step >= self.total_steps {
            self.lr_end
        } else {
            // Cosine decay
            let t = (step - self.warmup_steps) as F / (self.total_steps - self.warmup_steps) as F;
            let cos_decay = 0.5 * (1.0 + (std::f64::consts::PI * t).cos());
            self.lr_end + (self.lr_start - self.lr_end) * cos_decay
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_adamw_step() {
        let mut opt = AdamW::new(0.001, 0.01);
        
        let mut params = ParamDict::new();
        params.insert("w".to_string(), Param::Vector(DVector::from_vec(vec![1.0, 2.0, 3.0])));
        
        let mut grads = ParamDict::new();
        grads.insert("w".to_string(), Param::Vector(DVector::from_vec(vec![0.1, 0.2, 0.3])));
        
        // Take a step
        opt.step(&mut params, &grads);
        
        // Parameters should have decreased
        if let Param::Vector(w) = &params["w"] {
            assert!(w[0] < 1.0);
            assert!(w[1] < 2.0);
            assert!(w[2] < 3.0);
        }
    }
    
    #[test]
    fn test_cosine_schedule() {
        let schedule = CosineSchedule::new(1.0, 0.0, 100, 1000);
        
        // Warmup phase
        assert_eq!(schedule.get_lr(0), 0.0);
        assert_eq!(schedule.get_lr(50), 0.5);
        assert_eq!(schedule.get_lr(100), 1.0);
        
        // Cosine decay
        let mid_lr = schedule.get_lr(550); // Midpoint
        assert!(mid_lr > 0.4 && mid_lr < 0.6);
        
        // End
        assert!(schedule.get_lr(1000) <= 0.0);
    }
}