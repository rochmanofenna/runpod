// Standalone ENN mathematical tests - pure implementations
use nalgebra::{DMatrix, DVector};
use std::fs::File;
use std::io::Write;
use serde_json::json;

#[test]
fn psd_entanglement_matrix() {
    // Test PSD property of entanglement matrix E = L L^T
    println!("PSD Entanglement Matrix Test:");
    
    let sizes = vec![4, 8, 16];
    let num_trials = 5; // Reduced for speed
    let tolerance = 1e-10;
    
    for &k in &sizes {
        println!("Testing K={}", k);
        let mut min_eigenvalue_overall = f64::INFINITY;
        
        for trial in 0..num_trials {
            // Generate random L matrix
            let l = generate_random_l(k);
            
            // Compute E = L L^T
            let e = &l * l.transpose();
            
            // Check symmetry
            let symmetry_error = (&e - e.transpose()).amax();
            assert!(symmetry_error < 1e-12, 
                    "E not symmetric: max error {}", symmetry_error);
            
            // Compute eigenvalues
            let eigenvalues = e.symmetric_eigenvalues();
            let min_eig = eigenvalues.min();
            
            min_eigenvalue_overall = min_eigenvalue_overall.min(min_eig);
            
            // Check PSD property
            assert!(min_eig >= -tolerance,
                    "Negative eigenvalue {} < -{} at trial {} for K={}",
                    min_eig, tolerance, trial, k);
        }
        
        println!("  Min eigenvalue across trials: {:.3e}", min_eigenvalue_overall);
    }
    
    println!("✓ All entanglement matrices are PSD");
}

#[test]
fn collapse_numerics() {
    // Test softmax numerical properties and KL monotonicity
    println!("Collapse Numerics Test:");
    
    // Test softmax sum
    let test_cases = vec![
        vec![1.0, 2.0, 3.0, 4.0],
        vec![0.0, 0.0, 0.0, 0.0],
        vec![-5.0, 10.0, -2.0, 3.0],
        vec![100.0, 100.0, 100.0, 100.0], // Large values
        vec![-100.0, -100.0, -100.0, -100.0], // Small values
    ];
    
    for (_i, logits) in test_cases.iter().enumerate() {
        let alpha = softmax(&DVector::from_vec(logits.clone()));
        let sum = alpha.sum();
        let error = (sum - 1.0).abs();
        
        assert!(error < 1e-8,
                "Softmax sum {} deviates from 1 by more than 1e-8", sum);
    }
    
    // Test KL monotonicity  
    let _k = 5;
    let target_idx = 2;
    let base_logits = vec![0.5, -1.0, 2.0, -0.5, 1.0];
    let scaling_factors = vec![0.5, 1.0, 2.0, 4.0, 8.0];
    
    let mut kl_sequence = Vec::new();
    let mut sum_alphas = Vec::new();
    
    for &c in &scaling_factors {
        let scaled_logits = base_logits.iter()
            .map(|&x| x * c)
            .collect::<Vec<_>>();
        
        let alpha = softmax(&DVector::from_vec(scaled_logits));
        let kl = compute_kl_to_onehot(&alpha, target_idx);
        
        kl_sequence.push(kl);
        sum_alphas.push(alpha.sum());
    }
    
    // Check monotonicity
    for i in 1..kl_sequence.len() {
        assert!(kl_sequence[i] < kl_sequence[i-1] + 1e-10,
                "KL not decreasing: {} -> {} at c={} -> {}",
                kl_sequence[i-1], kl_sequence[i],
                scaling_factors[i-1], scaling_factors[i]);
    }
    
    // Save results
    let results = json!({
        "sum_alpha": sum_alphas[0],
        "kl_sequence": kl_sequence,
        "scaling_factors": scaling_factors,
    });
    
    std::fs::create_dir_all("runs").ok();
    let mut file = File::create("runs/enn_collapse.json").unwrap();
    write!(file, "{}", serde_json::to_string(&results).unwrap()).unwrap();
    
    println!("✓ Softmax and KL numerics are correct");
}

#[test] 
fn gradient_check_simple() {
    // Simple finite difference gradient check
    println!("Gradient Check Test:");
    
    let k = 4;
    let eps = 1e-5;
    
    // Test function: f(x) = x^T A x (quadratic form) where A is symmetric
    let a_temp = generate_random_l(k);
    let a = 0.5 * (&a_temp + a_temp.transpose()); // Make A symmetric
    let x = DVector::from_fn(k, |i, _| (i as f64 + 1.0) * 0.1);
    
    // Analytical gradient: grad f = 2 A x  
    let grad_analytical = 2.0 * &a * &x;
    
    // Finite difference gradient
    let mut grad_fd = DVector::zeros(k);
    for i in 0..k {
        let mut x_plus = x.clone();
        x_plus[i] += eps;
        let f_plus = (&x_plus.transpose() * &a * &x_plus)[0];
        
        let mut x_minus = x.clone();
        x_minus[i] -= eps;
        let f_minus = (&x_minus.transpose() * &a * &x_minus)[0];
        
        grad_fd[i] = (f_plus - f_minus) / (2.0 * eps);
    }
    
    // Compare gradients
    let error = (&grad_analytical - &grad_fd).norm() / grad_analytical.norm().max(1e-10);
    
    println!("  Relative gradient error: {:.3e}", error);
    
    assert!(error < 1e-4, "Gradient error {} exceeds 1e-4", error);
    
    // Save results
    let results = json!({
        "gradient_error": error,
        "analytical_grad_norm": grad_analytical.norm(),
        "fd_grad_norm": grad_fd.norm(),
    });
    
    std::fs::create_dir_all("runs").ok();  
    let mut file = File::create("runs/enn_gradcheck.json").unwrap();
    write!(file, "{}", serde_json::to_string(&results).unwrap()).unwrap();
    
    println!("✓ Gradient check passed");
}

// Helper functions
fn generate_random_l(k: usize) -> DMatrix<f64> {
    use rand_distr::{Distribution, StandardNormal};
    let mut rng = rand::thread_rng();
    
    DMatrix::from_fn(k, k, |_, _| {
        let val: f64 = StandardNormal.sample(&mut rng);
        val * 0.1
    })
}

fn softmax(logits: &DVector<f64>) -> DVector<f64> {
    let max_logit = logits.max();
    let exp_logits = logits.map(|x| (x - max_logit).exp());
    let sum_exp = exp_logits.sum();
    exp_logits / sum_exp
}

fn compute_kl_to_onehot(alpha: &DVector<f64>, target_idx: usize) -> f64 {
    let eps = 1e-15;
    -alpha[target_idx].max(eps).ln()
}