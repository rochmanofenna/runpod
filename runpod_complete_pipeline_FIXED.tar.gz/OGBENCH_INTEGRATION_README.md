# OGBench Integration for BICEP → ENN → FusionAlpha Pipeline

This integration connects OGBench (Offline Goal-Conditioned RL Benchmark) with your BICEP-ENN-FusionAlpha pipeline.

## Overview

The integration provides:
1. **Data conversion**: OGBench trajectories → BICEP SDE format
2. **ENN training**: Learn committor functions from offline data
3. **FusionAlpha planning**: Use trained ENN for goal-conditioned planning

## Files Created

- `ogbench_integration.py` - Main integration script with data converters
- `run_ogbench_pipeline.py` - Complete pipeline runner
- `test_ogbench.py` - Test script to verify OGBench installation
- `FusionAlpha/python/ogbench_integration.py` - FusionAlpha planner implementations

## Quick Start

1. **Test OGBench Installation**:
   ```bash
   python test_ogbench.py
   ```

2. **Run Full Pipeline**:
   ```bash
   python run_ogbench_pipeline.py --env antmaze-large-navigate-v0
   ```

3. **Run Individual Stages**:
   ```bash
   # Just BICEP conversion
   python ogbench_integration.py --env humanoidmaze-medium-navigate-v0 --stage bicep
   
   # Just ENN preparation  
   python ogbench_integration.py --env antsoccer-small-v0 --stage enn
   
   # Just FusionAlpha setup
   python ogbench_integration.py --env puzzle-3x3-play-v0 --stage fusion
   ```

## Supported Environments

### Locomotion
- `pointmaze-{small,medium,large}-navigate-v0`
- `antmaze-{small,medium,large}-navigate-v0`
- `humanoidmaze-{small,medium,large,giant}-navigate-v0`
- `antsoccer-{small,medium,large}-v0`

### Manipulation
- `cube-{single,double,triple,quadruple}-play-v0`
- `scene-play-v0`
- `puzzle-{3x3,4x4,4x5,4x6}-play-v0`

### Drawing
- `powderworld-{easy,medium,hard}-play-v0`

## Pipeline Architecture

```
OGBench Dataset
     ↓
[BICEP Converter]
     ↓
Parquet Trajectories
     ↓
[ENN Training]
     ↓
Committor Weights
     ↓
[FusionAlpha Planner]
     ↓
Goal-Conditioned Actions
```

## Data Flow

1. **OGBench → BICEP**:
   - Converts offline trajectories to SDE format
   - Extracts goal information for each task
   - Saves as Parquet files

2. **BICEP → ENN**:
   - Computes approximate committor values
   - Trains ENN to predict committors
   - Exports learned weights

3. **ENN → FusionAlpha**:
   - Uses ENN predictions as priors
   - Propagates committor values on task graph
   - Selects actions based on committor gradient

## Customization

### Adding New Environments

Edit `FusionAlpha/python/ogbench_integration.py`:

```python
class YourEnvPlanner(FusionAlphaPlanner):
    def build_graph(self, obs, goal):
        # Build task-specific graph
        pass
    
    def obs_to_dict(self, obs):
        # Convert observation format
        pass
    
    def action_from_node(self, obs, current_node, next_node):
        # Convert graph node to action
        pass
```

### Modifying Pipeline Parameters

Edit `run_ogbench_pipeline.py` to change:
- ENN training epochs
- FusionAlpha propagation steps
- Severity scaling
- Confidence weights

## Next Steps

1. **Fix Rust Bindings**: The FusionAlpha Python bindings need the missing functions:
   - `build_humanoid_graph_py`
   - `build_soccer_graph_py`
   - `build_puzzle_graph_py`

2. **Real ENN Training**: Replace mock training with actual Rust ENN binary

3. **GPU Acceleration**: Run on RunPod A100 for faster training

## Troubleshooting

- **ImportError for ogbench**: Run `pip install ogbench`
- **Missing fusion_alpha module**: Run `cd FusionAlpha && cargo build --release -p fusion-bindings`
- **BICEP conversion fails**: Check that environment name is correct
- **ENN training errors**: Ensure all dependencies from fixes are applied

## Running on RunPod

1. Upload the fixed codebase
2. Install OGBench: `pip install ogbench`
3. Run pipeline: `python run_ogbench_pipeline.py --env antmaze-large-navigate-v0`
4. Monitor GPU usage: `nvidia-smi -l 1`