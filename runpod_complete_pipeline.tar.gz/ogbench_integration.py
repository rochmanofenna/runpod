#!/usr/bin/env python3
"""
OGBench Integration for BICEP → ENN → FusionAlpha Pipeline

This script integrates OGBench environments and datasets with the 
BICEP-ENN-FusionAlpha pipeline for offline goal-conditioned RL.
"""

import numpy as np
import json
import argparse
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
import subprocess
import sys

# Try to import ogbench - install if not available
try:
    import ogbench
except ImportError:
    print("OGBench not found. Installing...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "ogbench"])
    import ogbench

# Try to import polars for data handling
try:
    import polars as pl
except ImportError:
    print("Polars not found. Installing...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "polars"])
    import polars as pl


class OGBenchToBICEP:
    """Convert OGBench trajectories to BICEP format for SDE modeling"""
    
    def __init__(self, env_name: str, output_dir: Path = Path("./ogbench_bicep_data")):
        self.env_name = env_name
        self.output_dir = output_dir
        self.output_dir.mkdir(exist_ok=True)
        
        # Load environment and datasets
        print(f"Loading OGBench environment: {env_name}")
        self.env, self.train_dataset, self.val_dataset = ogbench.make_env_and_datasets(
            env_name, 
            compact_dataset=False
        )
        
    def convert_to_bicep_format(self, dataset: Dict[str, np.ndarray], 
                               dataset_type: str = "train") -> Path:
        """
        Convert OGBench dataset to BICEP Parquet format
        
        BICEP expects:
        - path_id: trajectory identifier
        - step: timestep within trajectory
        - t: continuous time
        - state: state vector
        - x: first state dimension (for compatibility)
        """
        print(f"Converting {dataset_type} dataset to BICEP format...")
        
        observations = dataset['observations']
        actions = dataset['actions']
        terminals = dataset['terminals']
        rewards = dataset.get('rewards', np.zeros(len(observations)))
        
        # Detect trajectory boundaries
        trajectory_ends = np.where(terminals)[0]
        trajectory_starts = np.concatenate([[0], trajectory_ends[:-1] + 1])
        
        # Build BICEP-compatible data
        bicep_data = []
        
        for traj_idx, (start, end) in enumerate(zip(trajectory_starts, trajectory_ends)):
            traj_len = end - start + 1
            
            for step in range(traj_len):
                global_idx = start + step
                
                bicep_data.append({
                    'path_id': traj_idx,
                    'step': step,
                    't': step * 0.01,  # Assume dt=0.01
                    'state': observations[global_idx].tolist(),
                    'x': float(observations[global_idx][0]),  # First dimension
                    'action': actions[global_idx].tolist() if global_idx < len(actions) else None,
                    'reward': float(rewards[global_idx]) if global_idx < len(rewards) else 0.0,
                })
        
        # Convert to Polars DataFrame and save
        df = pl.DataFrame(bicep_data)
        output_path = self.output_dir / f"{self.env_name}_{dataset_type}.parquet"
        df.write_parquet(output_path)
        
        print(f"Saved {len(bicep_data)} transitions from {traj_idx + 1} trajectories to {output_path}")
        return output_path
    
    def generate_goal_data(self) -> Dict[str, Any]:
        """Extract goal information for FusionAlpha planning"""
        goals = []
        
        # Get evaluation goals from the environment
        for task_id in range(1, 6):  # OGBench provides 5 eval tasks
            obs, info = self.env.reset(options={'task_id': task_id})
            goal = info['goal']
            
            goals.append({
                'task_id': task_id,
                'goal_obs': goal.tolist() if isinstance(goal, np.ndarray) else goal,
                'goal_dim': len(goal) if isinstance(goal, np.ndarray) else 1,
            })
        
        goal_info = {
            'env_name': self.env_name,
            'goals': goals,
            'obs_dim': self.env.observation_space.shape[0],
            'action_dim': self.env.action_space.shape[0],
        }
        
        # Save goal information
        goal_path = self.output_dir / f"{self.env_name}_goals.json"
        with open(goal_path, 'w') as f:
            json.dump(goal_info, f, indent=2)
        
        print(f"Saved goal information to {goal_path}")
        return goal_info


class OGBenchENN:
    """Train ENN on OGBench trajectories for committor prediction"""
    
    def __init__(self, bicep_data_path: Path, goal_info_path: Path):
        self.bicep_data_path = bicep_data_path
        self.goal_info_path = goal_info_path
        
        # Load goal information
        with open(goal_info_path, 'r') as f:
            self.goal_info = json.load(f)
    
    def prepare_training_script(self) -> Path:
        """Create ENN training script adapted for OGBench data"""
        
        script_content = f'''#!/usr/bin/env python3
"""
ENN Training on OGBench Data
Auto-generated script for training ENN on converted OGBench trajectories
"""

import polars as pl
import numpy as np
import json
from pathlib import Path

# Load BICEP-format data
print("Loading trajectory data from {self.bicep_data_path}")
df = pl.read_parquet("{self.bicep_data_path}")

# Extract state dimensions
obs_dim = {self.goal_info['obs_dim']}
action_dim = {self.goal_info['action_dim']}

print(f"Observation dimension: {{obs_dim}}")
print(f"Action dimension: {{action_dim}}")
print(f"Total transitions: {{len(df)}}")

# Prepare data for ENN training
# Group by trajectory
trajectories = df.group_by("path_id").agg([
    pl.col("state").alias("states"),
    pl.col("t").alias("times"),
    pl.col("reward").alias("rewards"),
])

print(f"Number of trajectories: {{len(trajectories)}}")

# Compute approximate committors based on goal-reaching
# This is a simplified version - in practice, you'd use proper goal distances
def compute_committor(states, goal_state):
    """Compute committor values based on distance to goal"""
    committors = []
    for state in states:
        # Simple L2 distance to goal (would be more sophisticated in practice)
        dist = np.linalg.norm(np.array(state[:len(goal_state)]) - np.array(goal_state))
        committor = np.exp(-dist / 10.0)  # Exponential decay
        committors.append(committor)
    return committors

# Load goals
with open("{self.goal_info_path}", 'r') as f:
    goal_info = json.load(f)

# For now, use first goal as target
goal_obs = goal_info['goals'][0]['goal_obs']

# Add committor values
all_committors = []
for row in trajectories.iter_rows():
    path_id, states, times, rewards = row
    committors = compute_committor(states, goal_obs)
    all_committors.extend(committors)

print(f"Computed {{len(all_committors)}} committor values")
print(f"Mean committor: {{np.mean(all_committors):.3f}}")
print(f"Std committor: {{np.std(all_committors):.3f}}")

# Save training data for ENN
training_data = {{
    "trajectories": trajectories.to_dict(),
    "committors": all_committors,
    "goal_info": goal_info,
    "env_name": "{self.goal_info['env_name']}",
}}

output_path = Path("{self.bicep_data_path}").parent / "enn_training_data.json"
with open(output_path, 'w') as f:
    json.dump(training_data, f)

print(f"Saved ENN training data to {{output_path}}")
print("\\nNext steps:")
print("1. Run ENN training with: cd ENNsrc/ENNrust/enn && cargo run --release --bin collapse_committor")
print("2. Use trained ENN weights in FusionAlpha planning")
'''
        
        script_path = Path(self.bicep_data_path).parent / "train_enn_ogbench.py"
        with open(script_path, 'w') as f:
            f.write(script_content)
        
        script_path.chmod(0o755)
        print(f"Created ENN training script: {script_path}")
        return script_path


class OGBenchFusionAlpha:
    """Use FusionAlpha for planning in OGBench environments"""
    
    def __init__(self, env_name: str, enn_weights_path: Optional[Path] = None):
        self.env_name = env_name
        self.enn_weights_path = enn_weights_path
        
        # Create environment
        self.env, _, _ = ogbench.make_env_and_datasets(env_name, env_only=True)
        
    def create_planning_script(self) -> Path:
        """Create FusionAlpha planning script for OGBench"""
        
        script_content = f'''#!/usr/bin/env python3
"""
FusionAlpha Planning for OGBench
Uses the Fusion Alpha committor-based planning for OGBench environments
"""

import numpy as np
import json
from pathlib import Path

# OGBench environment
env_name = "{self.env_name}"

# Import fusion alpha bindings (if available)
# In practice, this would use the Rust FusionAlpha implementation
# For now, we'll create a mock planning function

def fusion_alpha_plan(obs, goal, enn_weights=None):
    """
    Plan using FusionAlpha committor propagation
    
    This would call the Rust implementation via Python bindings
    """
    # Mock implementation - replace with actual FusionAlpha call
    # In reality, this would:
    # 1. Build graph from current observation
    # 2. Use ENN to set priors
    # 3. Propagate committor values
    # 4. Select action based on committor gradient
    
    # For now, return a random action
    action_dim = {self.env.action_space.shape[0]}
    return np.random.randn(action_dim) * 0.1

# Load ENN weights if available
enn_weights = None
if Path("{self.enn_weights_path or 'none'}").exists():
    with open("{self.enn_weights_path}", 'r') as f:
        enn_weights = json.load(f)
    print("Loaded ENN weights")

# Evaluation loop
print(f"Evaluating FusionAlpha on {{env_name}}")

# Import ogbench
import ogbench
env, _, _ = ogbench.make_env_and_datasets(env_name, env_only=True)

# Run evaluation on all 5 tasks
results = []
for task_id in range(1, 6):
    print(f"\\nTask {{task_id}}:")
    
    obs, info = env.reset(options={{'task_id': task_id}})
    goal = info['goal']
    
    done = False
    steps = 0
    
    while not done and steps < 1000:
        # Plan action using FusionAlpha
        action = fusion_alpha_plan(obs, goal, enn_weights)
        
        # Execute action
        obs, reward, terminated, truncated, info = env.step(action)
        done = terminated or truncated
        steps += 1
        
        if steps % 100 == 0:
            print(f"  Step {{steps}}")
    
    success = info.get('success', False)
    print(f"  Result: {{'success': {{success}}, 'steps': {{steps}}}}")
    
    results.append({{
        'task_id': task_id,
        'success': success,
        'steps': steps,
    }})

# Summary
successes = sum(r['success'] for r in results)
print(f"\\nOverall success rate: {{successes}}/5 = {{successes/5*100:.1f}}%")
print(f"Average steps: {{np.mean([r['steps'] for r in results]):.1f}}")
'''
        
        script_path = Path(self.enn_weights_path or Path.cwd()).parent / f"fusion_alpha_{self.env_name}.py"
        with open(script_path, 'w') as f:
            f.write(script_content)
        
        script_path.chmod(0o755)
        print(f"Created FusionAlpha planning script: {script_path}")
        return script_path


def main():
    parser = argparse.ArgumentParser(description="OGBench Integration for BICEP-ENN-FusionAlpha")
    parser.add_argument('--env', default='antmaze-large-navigate-v0', 
                       help='OGBench environment name')
    parser.add_argument('--output-dir', default='./ogbench_pipeline_data',
                       help='Output directory for processed data')
    parser.add_argument('--stage', choices=['all', 'bicep', 'enn', 'fusion'], 
                       default='all', help='Which stage to run')
    
    args = parser.parse_args()
    output_dir = Path(args.output_dir)
    
    print(f"=== OGBench Integration Pipeline ===")
    print(f"Environment: {args.env}")
    print(f"Output directory: {output_dir}")
    print(f"Stage: {args.stage}")
    print()
    
    # Stage 1: Convert OGBench to BICEP format
    if args.stage in ['all', 'bicep']:
        print("Stage 1: Converting OGBench data to BICEP format...")
        converter = OGBenchToBICEP(args.env, output_dir)
        
        # Convert datasets
        train_path = converter.convert_to_bicep_format(converter.train_dataset, 'train')
        val_path = converter.convert_to_bicep_format(converter.val_dataset, 'val')
        
        # Extract goal information
        goal_info = converter.generate_goal_data()
        print(f"✓ BICEP conversion complete")
        print()
    
    # Stage 2: Prepare ENN training
    if args.stage in ['all', 'enn']:
        print("Stage 2: Preparing ENN training...")
        bicep_path = output_dir / f"{args.env}_train.parquet"
        goal_path = output_dir / f"{args.env}_goals.json"
        
        if not bicep_path.exists():
            print("ERROR: BICEP data not found. Run with --stage=bicep first.")
            return
        
        enn_adapter = OGBenchENN(bicep_path, goal_path)
        train_script = enn_adapter.prepare_training_script()
        
        print(f"✓ ENN training script created: {train_script}")
        print("  Run it with: python {train_script}")
        print()
    
    # Stage 3: Create FusionAlpha planning
    if args.stage in ['all', 'fusion']:
        print("Stage 3: Creating FusionAlpha planning script...")
        enn_weights = output_dir / "enn_weights.json"  # Would be created by ENN training
        
        planner = OGBenchFusionAlpha(args.env, enn_weights)
        planning_script = planner.create_planning_script()
        
        print(f"✓ FusionAlpha planning script created: {planning_script}")
        print(f"  Run it with: python {planning_script}")
        print()
    
    print("=== Pipeline Summary ===")
    print(f"1. BICEP data: {output_dir}/{args.env}_*.parquet")
    print(f"2. ENN training: {output_dir}/train_enn_ogbench.py")
    print(f"3. FusionAlpha: {output_dir}/fusion_alpha_{args.env}.py")
    print()
    print("Next steps:")
    print("1. Run the ENN training script to train on OGBench data")
    print("2. Use the trained ENN weights with FusionAlpha planning")
    print("3. Evaluate the full pipeline on OGBench tasks")


if __name__ == "__main__":
    main()