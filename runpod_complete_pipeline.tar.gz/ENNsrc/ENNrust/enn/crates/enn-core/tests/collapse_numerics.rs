use nalgebra::DVector;
use std::fs::File;
use std::io::Write;
use serde_json::json;

#[test]
fn collapse_numerics() {
    // Test softmax numerical properties
    test_softmax_sum();
    
    // Test KL divergence monotonicity
    test_kl_monotonicity();
}

fn test_softmax_sum() {
    println!("Testing softmax sum to 1:");
    
    let test_cases = vec![
        vec![1.0, 2.0, 3.0, 4.0],
        vec![0.0, 0.0, 0.0, 0.0],
        vec![-5.0, 10.0, -2.0, 3.0],
        vec![100.0, 100.0, 100.0, 100.0], // Large values
        vec![-100.0, -100.0, -100.0, -100.0], // Small values
    ];
    
    for (i, logits) in test_cases.iter().enumerate() {
        let alpha = softmax(&DVector::from_vec(logits.clone()));
        let sum = alpha.sum();
        let error = (sum - 1.0).abs();
        
        println!("  Test case {}: sum={:.12}, error={:.3e}", i, sum, error);
        
        assert!(error < 1e-8,
                "Softmax sum {} deviates from 1 by more than 1e-8", sum);
    }
}

fn test_kl_monotonicity() {
    println!("\nTesting KL divergence monotonicity:");
    
    let _k = 5;
    let target_idx = 2;
    let base_logits = vec![0.5, -1.0, 2.0, -0.5, 1.0];
    let scaling_factors = vec![0.5, 1.0, 2.0, 4.0, 8.0];
    
    let mut kl_sequence = Vec::new();
    let mut sum_alphas = Vec::new();
    
    for &c in &scaling_factors {
        // Scale logits
        let scaled_logits = base_logits.iter()
            .map(|&x| x * c)
            .collect::<Vec<_>>();
        
        let alpha = softmax(&DVector::from_vec(scaled_logits));
        let kl = compute_kl_to_onehot(&alpha, target_idx);
        
        kl_sequence.push(kl);
        sum_alphas.push(alpha.sum());
        
        println!("  c={:.1}: KL={:.6}, α[target]={:.6}", 
                 c, kl, alpha[target_idx]);
    }
    
    // Check monotonicity: KL should decrease as c increases
    for i in 1..kl_sequence.len() {
        assert!(kl_sequence[i] < kl_sequence[i-1] + 1e-10,
                "KL not decreasing: {} -> {} at c={} -> {}",
                kl_sequence[i-1], kl_sequence[i],
                scaling_factors[i-1], scaling_factors[i]);
    }
    
    // Save results
    let results = json!({
        "sum_alpha": sum_alphas[0], // All should be ~1
        "kl_sequence": kl_sequence,
        "scaling_factors": scaling_factors,
    });
    
    std::fs::create_dir_all("runs").ok();
    let mut file = File::create("runs/enn_collapse.json").unwrap();
    write!(file, "{}", serde_json::to_string(&results).unwrap()).unwrap();
    
    println!("  KL sequence: {:?}", kl_sequence);
    println!("  ✓ KL monotonically decreases with scaling");
}

fn softmax(logits: &DVector<f64>) -> DVector<f64> {
    // Numerically stable softmax
    let max_logit = logits.max();
    let exp_logits = logits.map(|x| (x - max_logit).exp());
    let sum_exp = exp_logits.sum();
    exp_logits / sum_exp
}

fn compute_kl_to_onehot(alpha: &DVector<f64>, target_idx: usize) -> f64 {
    // KL(α || one_hot)
    // = -sum_i one_hot[i] * log(α[i]) + sum_i one_hot[i] * log(one_hot[i])
    // = -log(α[target_idx]) + 0
    // = -log(α[target_idx])
    
    let eps = 1e-15; // Avoid log(0)
    -alpha[target_idx].max(eps).ln()
}

#[test]
fn softmax_gradient_stability() {
    // Test numerical stability of softmax gradients
    println!("\nTesting softmax gradient stability:");
    
    let k = 4;
    let logits = DVector::from_vec(vec![50.0, 51.0, 49.0, 50.5]);
    
    let alpha = softmax(&logits);
    
    // Compute Jacobian of softmax
    let mut jacobian = DMatrix::zeros(k, k);
    for i in 0..k {
        for j in 0..k {
            if i == j {
                jacobian[(i, j)] = alpha[i] * (1.0 - alpha[i]);
            } else {
                jacobian[(i, j)] = -alpha[i] * alpha[j];
            }
        }
    }
    
    // Check that Jacobian rows sum to 0 (property of softmax)
    for i in 0..k {
        let row_sum = jacobian.row(i).sum();
        assert!(row_sum.abs() < 1e-10,
                "Softmax Jacobian row {} sum {} != 0", i, row_sum);
    }
    
    println!("  ✓ Softmax Jacobian is numerically stable");
}

use nalgebra::DMatrix;