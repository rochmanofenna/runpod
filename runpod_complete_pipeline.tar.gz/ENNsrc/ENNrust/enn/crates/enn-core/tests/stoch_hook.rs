use nalgebra::DVector;
use std::fs::File;
use std::io::Write;

#[test]
#[ignore] // Run with --ignored flag when stochastic hook is implemented
fn stoch_hook() {
    println!("Stochastic Hook Test (Itô vs Stratonovich for ψ dynamics)");
    println!("NOTE: This test requires the stochastic hook to be implemented");
    
    // Test parameters
    let k = 4;
    let dt_values = vec![1e-1, 5e-2, 2e-2, 1e-2, 5e-3];
    let n_paths = 100_000;
    let steps_per_dt = 100;
    
    // Diagonal diffusion coefficients for ψ
    let sigma_psi = DVector::from_vec(vec![0.3, 0.4, 0.2, 0.5]);
    
    let mut csv_content = String::from("dt,ks_distance\n");
    
    for &dt in &dt_values {
        println!("\nTesting dt={}", dt);
        
        // Simulate paths with Itô EM
        let ito_finals = simulate_psi_ito(k, &sigma_psi, dt, steps_per_dt, n_paths);
        
        // Simulate paths with Stratonovich Heun
        let strat_finals = simulate_psi_strat(k, &sigma_psi, dt, steps_per_dt, n_paths);
        
        // Compute KS distance
        let ks_dist = compute_ks_distance_components(&ito_finals, &strat_finals);
        
        println!("  KS distance: {:.6}", ks_dist);
        csv_content.push_str(&format!("{},{}\n", dt, ks_dist));
    }
    
    // Save results
    std::fs::create_dir_all("runs").ok();
    let mut file = File::create("runs/enn_stoch_ks.csv").unwrap();
    write!(file, "{}", csv_content).unwrap();
    
    // Check convergence at smallest dt
    let dt_small = dt_values.last().unwrap();
    let ito_finals = simulate_psi_ito(k, &sigma_psi, *dt_small, steps_per_dt, n_paths);
    let strat_finals = simulate_psi_strat(k, &sigma_psi, *dt_small, steps_per_dt, n_paths);
    let ks_dist_small = compute_ks_distance_components(&ito_finals, &strat_finals);
    
    assert!(ks_dist_small < 0.05,
            "KS distance {} at dt={} exceeds 0.05", ks_dist_small, dt_small);
}

fn simulate_psi_ito(
    k: usize,
    sigma_psi: &DVector<f64>,
    dt: f64,
    steps: usize,
    n_paths: usize,
) -> Vec<DVector<f64>> {
    // Placeholder for Itô simulation
    // In real implementation, this would use the ENN stochastic hook
    let mut finals = Vec::with_capacity(n_paths);
    
    for _ in 0..n_paths {
        // Simplified: just return normal samples for now
        let psi_final = DVector::from_fn(k, |i, _| {
            // Approximate final distribution
            let variance = sigma_psi[i].powi(2) * dt * steps as f64;
            rand_distr::Normal::new(0.0, variance.sqrt())
                .unwrap()
                .sample(&mut rand::thread_rng())
        });
        finals.push(psi_final);
    }
    
    finals
}

fn simulate_psi_strat(
    k: usize,
    sigma_psi: &DVector<f64>,
    dt: f64,
    steps: usize,
    n_paths: usize,
) -> Vec<DVector<f64>> {
    // Placeholder for Stratonovich simulation
    // In real implementation, this would use Heun midpoint method
    let mut finals = Vec::with_capacity(n_paths);
    
    for _ in 0..n_paths {
        // Simplified: just return normal samples with slight bias
        let psi_final = DVector::from_fn(k, |i, _| {
            // Approximate final distribution (with small drift correction)
            let variance = sigma_psi[i].powi(2) * dt * steps as f64;
            let drift_correction = 0.01 * dt * steps as f64; // Placeholder
            rand_distr::Normal::new(drift_correction, variance.sqrt())
                .unwrap()
                .sample(&mut rand::thread_rng())
        });
        finals.push(psi_final);
    }
    
    finals
}

fn compute_ks_distance_components(
    samples1: &[DVector<f64>],
    samples2: &[DVector<f64>],
) -> f64 {
    // Compute average KS distance across components
    let k = samples1[0].len();
    let mut total_ks = 0.0;
    
    for component in 0..k {
        // Extract component values
        let vals1: Vec<f64> = samples1.iter().map(|v| v[component]).collect();
        let vals2: Vec<f64> = samples2.iter().map(|v| v[component]).collect();
        
        let ks = compute_ks_distance(&vals1, &vals2);
        total_ks += ks;
    }
    
    total_ks / k as f64
}

fn compute_ks_distance(sample1: &[f64], sample2: &[f64]) -> f64 {
    let n1 = sample1.len();
    let n2 = sample2.len();
    
    // Combine and sort
    let mut all_values: Vec<(f64, bool)> = Vec::with_capacity(n1 + n2);
    for &x in sample1 {
        all_values.push((x, true));
    }
    for &x in sample2 {
        all_values.push((x, false));
    }
    all_values.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
    
    // Compute KS statistic
    let mut d_max: f64 = 0.0;
    let mut count1 = 0;
    let mut count2 = 0;
    
    for &(_, from_sample1) in &all_values {
        if from_sample1 {
            count1 += 1;
        } else {
            count2 += 1;
        }
        
        let cdf1 = count1 as f64 / n1 as f64;
        let cdf2 = count2 as f64 / n2 as f64;
        let d = (cdf1 - cdf2).abs();
        
        d_max = d_max.max(d);
    }
    
    d_max
}

use rand_distr::Distribution;