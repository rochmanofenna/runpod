#!/usr/bin/env python3
"""
Quick test script for OGBench environments
Tests basic functionality and shows what data is available
"""

import subprocess
import sys

# Install ogbench if needed
try:
    import ogbench
except ImportError:
    print("Installing ogbench...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "ogbench"])
    import ogbench

import numpy as np


def test_ogbench_env(env_name='antmaze-large-navigate-v0'):
    """Test basic OGBench environment functionality"""
    
    print(f"\n=== Testing OGBench Environment: {env_name} ===")
    
    # Create environment and load datasets
    print("Loading environment and datasets...")
    env, train_dataset, val_dataset = ogbench.make_env_and_datasets(env_name)
    
    print(f"\nEnvironment info:")
    print(f"  Observation space: {env.observation_space}")
    print(f"  Action space: {env.action_space}")
    
    print(f"\nDataset info:")
    print(f"  Training transitions: {len(train_dataset['observations'])}")
    print(f"  Validation transitions: {len(val_dataset['observations'])}")
    print(f"  Dataset keys: {list(train_dataset.keys())}")
    
    # Test environment reset and step
    print("\nTesting environment interaction:")
    
    for task_id in [1, 2]:
        print(f"\n  Task {task_id}:")
        obs, info = env.reset(options={'task_id': task_id})
        
        print(f"    Initial obs shape: {obs.shape}")
        print(f"    Goal shape: {info['goal'].shape}")
        print(f"    Info keys: {list(info.keys())}")
        
        # Take a few random steps
        for step in range(5):
            action = env.action_space.sample()
            obs, reward, terminated, truncated, info = env.step(action)
            
            if step == 0:
                print(f"    After step 1:")
                print(f"      Reward: {reward}")
                print(f"      Terminated: {terminated}")
                print(f"      Truncated: {truncated}")
        
        print(f"    Success after 5 steps: {info.get('success', False)}")
    
    # Analyze dataset structure
    print("\nDataset structure analysis:")
    
    # Find trajectory boundaries
    terminals = train_dataset['terminals']
    trajectory_ends = np.where(terminals)[0]
    n_trajectories = len(trajectory_ends)
    
    print(f"  Number of trajectories: {n_trajectories}")
    if n_trajectories > 0:
        traj_lengths = np.diff(np.concatenate([[-1], trajectory_ends]))
        print(f"  Average trajectory length: {np.mean(traj_lengths):.1f}")
        print(f"  Min/Max trajectory length: {np.min(traj_lengths)}/{np.max(traj_lengths)}")
    
    # Sample observation statistics
    obs_mean = np.mean(train_dataset['observations'], axis=0)
    obs_std = np.std(train_dataset['observations'], axis=0)
    print(f"  Observation mean (first 5 dims): {obs_mean[:5]}")
    print(f"  Observation std (first 5 dims): {obs_std[:5]}")
    
    print("\n✓ OGBench test complete!")
    

def list_available_envs():
    """List some available OGBench environments"""
    
    print("\n=== Available OGBench Environments ===")
    
    env_categories = {
        "Locomotion": [
            "pointmaze-large-navigate-v0",
            "antmaze-large-navigate-v0", 
            "humanoidmaze-medium-navigate-v0",
            "antsoccer-small-v0",
        ],
        "Manipulation": [
            "cube-single-play-v0",
            "cube-double-play-v0",
            "scene-play-v0",
            "puzzle-3x3-play-v0",
        ],
        "Drawing": [
            "powderworld-easy-play-v0",
        ],
    }
    
    for category, envs in env_categories.items():
        print(f"\n{category}:")
        for env in envs:
            print(f"  - {env}")
    
    print("\nEach environment also has:")
    print("  - 5 evaluation tasks (task_id 1-5)")
    print("  - State and pixel observation modes")
    print("  - Pre-collected offline datasets")
    

def test_bicep_compatibility():
    """Test if OGBench data can be converted to BICEP format"""
    
    print("\n=== Testing BICEP Compatibility ===")
    
    env_name = 'pointmaze-large-navigate-v0'
    env, train_dataset, _ = ogbench.make_env_and_datasets(env_name)
    
    # Check data format
    print(f"Dataset shape compatibility:")
    print(f"  Observations: {train_dataset['observations'].shape}")
    print(f"  Actions: {train_dataset['actions'].shape}")
    print(f"  Can extract trajectories: {np.any(train_dataset['terminals'])}")
    
    # Mock BICEP trajectory format
    print(f"\nBICEP trajectory format:")
    print(f"  path_id: int")
    print(f"  step: int")  
    print(f"  t: float")
    print(f"  state: List[float]")
    print(f"  Compatible: ✓")
    

if __name__ == "__main__":
    # List available environments
    list_available_envs()
    
    # Test a specific environment
    test_ogbench_env('antmaze-large-navigate-v0')
    
    # Test BICEP compatibility
    test_bicep_compatibility()
    
    print("\n=== All tests complete! ===")
    print("\nTo run the full pipeline:")
    print("  python run_ogbench_pipeline.py --env antmaze-large-navigate-v0")
    print("\nTo run just the integration script:")
    print("  python ogbench_integration.py --env humanoidmaze-medium-navigate-v0")