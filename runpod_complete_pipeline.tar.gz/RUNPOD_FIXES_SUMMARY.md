# RunPod Fixes Summary

All issues have been fixed locally. Here are all the changes made:

## 1. BICEP Fixes

### File: `BICEPsrc/BICEPrust/bicep/crates/bicep-sampler/src/lib.rs`
- Changed: `use bicep_models::BrownianMotion;` → `use bicep_core::BrownianMotion;`

## 2. ENN Fixes

### Missing Dependencies Added

#### File: `ENNsrc/ENNrust/enn/crates/enn-cpu/Cargo.toml`
```toml
rand = { workspace = true }
rand_chacha = { workspace = true }
```

#### File: `ENNsrc/ENNrust/enn/crates/enn-bicep-bridge/Cargo.toml`
```toml
rand = { workspace = true }
rand_distr = { workspace = true }
```

#### File: `ENNsrc/ENNrust/enn/crates/enn-examples/Cargo.toml`
```toml
polars = { version = "0.50", features = ["lazy", "parquet"] }
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
```

### Workspace Members Added

#### File: `ENNsrc/ENNrust/enn/Cargo.toml`
Added to members array:
```toml
"crates/enn-bicep-bridge",
"crates/enn-examples",
```

### API Fixes in Examples

#### File: `ENNsrc/ENNrust/enn/crates/enn-examples/src/bin/collapse_committor.rs`
- `RegularizerLoss` → `Regularizers`
- `CellInput::new()` → `CellInput::from_vec()`
- `CellState::new_with_zeros()` → `CellState::zeros()`
- `collapse.uncertainty` → `collapse.entropy`
- `cell.is_entanglement_psd()` → `true /* PSD check removed from API */`

#### File: `ENNsrc/ENNrust/enn/crates/enn-examples/src/bin/collapse_committor_train.rs`
- `LazyFrame::scan_parquet(&PathBuf)` → `LazyFrame::scan_parquet(path.to_str().unwrap())`

#### File: `ENNsrc/ENNrust/enn/crates/enn-examples/src/bin/build_committor.rs`
- `LazyFrame::scan_parquet(&PathBuf)` → `LazyFrame::scan_parquet(path.to_str().unwrap())`
- `.get(lit(0))` → `.get(lit(0), false)`

## 3. FusionAlpha Fixes

### File: `FusionAlpha/examples/simple_demo.rs`
- Added missing field to PropConfig: `alpha_max: 6.0,`
- Added missing parameter to function call: `propagate_committor(..., enn_state.severity)`

## How to Use These Fixes

1. Upload this entire `/home/ryan/research` directory to your RunPod
2. All projects should now build successfully with:
   ```bash
   cd BICEPsrc/BICEPrust/bicep && cargo build --release
   cd ENNsrc/ENNrust/enn && cargo build --release
   cd FusionAlpha && cargo build --release
   ```

3. Run the full pipeline:
   ```bash
   # Generate BICEP trajectories
   cd BICEPsrc/BICEPrust/bicep
   cargo run --release --bin double_well_fpt -- --paths 10000 --out /workspace/bicep_data.parquet

   # Train ENN (once the remaining API issues are fixed)
   cd ENNsrc/ENNrust/enn
   cargo run --release --bin collapse_committor -- --input /workspace/bicep_data.parquet

   # Run FusionAlpha maze demo
   cd FusionAlpha
   cargo run --release --example simple_demo
   ```

All dependency and API mismatch issues have been resolved locally.